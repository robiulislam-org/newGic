Set oShell = CreateObject("WScript.Shell")
Set oFSO = CreateObject("Scripting.FileSystemObject")

Dim scriptDir, batPath
scriptDir = oFSO.GetParentFolderName(WScript.ScriptFullName)
batPath = scriptDir & "\GIC_Start.bat"

If oFSO.FileExists(batPath) Then
    oShell.Run """" & batPath & """", 1, False
Else
    MsgBox "GIC_Start.bat not found!", vbCritical, "GIC Bot"
End If