﻿// ═══════════════════════════════════════════════════════════════
//  GIC.js — Global Islamic Care — একটাই File, সব কিছু এখানে
//  ✅ একটাই WhatsApp সংযোগ — CLS Bot + Report Bot দুটোই
//  Port: 3000  →  http://localhost:3000
// ═══════════════════════════════════════════════════════════════

'use strict';

// ── Google Drive Fix: Local node_modules path ──────────────────
// Google Drive-এ node_modules কাজ করে না (EISDIR/ETIMEDOUT error)
// তাই C:\GIC_Local\node_modules থেকে module লোড করা হচ্ছে
const Module = require('module');
const LOCAL_MODULES = 'C:\\GIC_Local\\node_modules';
const _orig = Module._resolveFilename.bind(Module);
Module._resolveFilename = function(req, parent, isMain, opts) {
  try { return _orig(req, parent, isMain, opts); } catch(e) {
    const path = require('path');
    try {
      return _orig(req, { ...(parent||{}), paths: [LOCAL_MODULES, ...(parent&&parent.paths||[])] }, isMain, opts);
    } catch(_) { throw e; }
  }
};
const { Client, LocalAuth, MessageMedia } = require('whatsapp-web.js');
const qrcode        = require('qrcode-terminal');
const qrcodeImage   = require('qrcode'); // ✅ local QR image generation — internet ছাড়াই কাজ করবে
const puppeteer     = require('puppeteer');
const express       = require('express');
const http          = require('http');
const fs            = require('fs');
const path          = require('path');
const { exec }      = require('child_process');

// ── Paths ──────────────────────────────────────────────────────
// GIC_DATA_ROOT is set by GIC_Start.bat so data files are always
const defaultDrivePath = 'g:/My Drive/My Laptop Backup/D_Drive_Files/GIC Student control';
let ROOT = (process.env.GIC_DATA_ROOT || '').trim();
if (!ROOT || !fs.existsSync(path.resolve(ROOT, '01 - CLS Bot', 'files', 'dashboard', 'index.html'))) {
  const relParent = path.resolve(__dirname, '..');
  if (fs.existsSync(path.resolve(relParent, '01 - CLS Bot', 'files', 'dashboard', 'index.html'))) {
    ROOT = relParent;
  } else if (fs.existsSync(defaultDrivePath)) {
    ROOT = path.resolve(defaultDrivePath);
  }
}
const CLS_DIR      = path.join(ROOT, '01 - CLS Bot', 'files');
const RPT_DIR      = path.join(ROOT, '02 - Report Generator', 'GIC Report Pro', 'bot');
const SCHED_FILE   = path.join(CLS_DIR, 'schedule.json');
const SENT_LOG     = path.join(RPT_DIR, 'sent_log.json');
const STUDENTS     = path.join(RPT_DIR, 'students.json');
const HISTORY      = path.join(RPT_DIR, 'history.json');
const TEACHERS     = path.join(__dirname, 'teachers.json');
// Auth & cache local-এ রাখো — Google Drive-এ রাখলে অনেক ধীরে হয়
const AUTH_PATH    = 'C:\\GIC_Local\\.wwebjs_auth';
const CACHE_PATH   = 'C:\\GIC_Local\\.wwebjs_cache';
const QR_FILE      = path.join(ROOT, 'GIC App', 'qr.png');

// ── Simple password hashing (crypto built-in) ──────────────────
const crypto = require('crypto');
function hashPassword(pw) {
  return crypto.createHash('sha256').update('gic_salt_' + pw).digest('hex');
}
function verifyPassword(pw, hash) {
  return hashPassword(pw) === hash;
}

// ── Teacher Data Helpers ───────────────────────────────────────
function loadTeachers() {
  try {
    if (!fs.existsSync(TEACHERS)) return [];
    return JSON.parse(fs.readFileSync(TEACHERS, 'utf-8'));
  } catch(e) {
    addLog('warn', 'teachers.json লোড ব্যর্থ: ' + e.message);
    return [];
  }
}
function saveTeachers(arr) {
  fs.writeFileSync(TEACHERS, JSON.stringify(arr, null, 2), 'utf-8');
}

// ── Teacher Session Store (memory) ────────────────────────────
// Simple token → teacherId map; expires in 24h
const teacherSessions = new Map(); // token → { teacherId, expires }
function createTeacherToken(teacherId) {
  const token = crypto.randomBytes(32).toString('hex');
  const expires = Date.now() + 24 * 60 * 60 * 1000; // 24h
  teacherSessions.set(token, { teacherId, expires });
  return token;
}
function validateTeacherToken(token) {
  if (!token) return null;
  const session = teacherSessions.get(token);
  if (!session) return null;
  if (Date.now() > session.expires) { teacherSessions.delete(token); return null; }
  return session.teacherId;
}
function invalidateTeacherToken(token) {
  teacherSessions.delete(token);
}
// ✅ Cleanup expired sessions every hour
setInterval(() => {
  const now = Date.now();
  for (const [tok, sess] of teacherSessions.entries()) {
    if (now > sess.expires) teacherSessions.delete(tok);
  }
}, 60 * 60 * 1000);

// ── Teacher Auth Middleware ────────────────────────────────────
function teacherAuth(req, res, next) {
  const token = req.headers['x-teacher-token'] || req.query.token;
  const teacherId = validateTeacherToken(token);
  if (!teacherId) return res.status(401).json({ error: 'অনুমতি নেই। আবার লগইন করুন।' });
  const teachers = loadTeachers();
  const teacher = teachers.find(t => t.id === teacherId);
  if (!teacher) return res.status(401).json({ error: 'শিক্ষক পাওয়া যায়নি।' });
  req.teacher = teacher;
  next();
}

// ── WhatsApp State (একটাই) ─────────────────────────────────────
let waReady        = false;
let waStatus       = 'connecting';
let waQR           = null;
let waReconnecting = false; // reconnect loop guard
let waWarmupTimer  = null;  // ready warmup timer — disconnect হলে cancel করা হয়
const waLogs = [];


// ── CLS Bot State ──────────────────────────────────────────────
let isJoiningMeet = false, activeMeetBrowser = null;
let isCheckingSchedule = false;
const sentToday = new Set(), joinedToday = new Set();
const DAY_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const CHECK_INTERVAL_MS = 30 * 1000;
const BOT_PROFILE_DIR = path.join(CLS_DIR, '.meet_profile');

// ── Log helper ─────────────────────────────────────────────────
function addLog(type, msg) {
  const entry = { type, msg, time: new Date().toISOString() };
  waLogs.push(entry);
  if (waLogs.length > 300) waLogs.shift();
  const ico = { info:'ℹ️', success:'✅', error:'❌', warn:'⚠️' };
  console.log(`[GIC] ${ico[type]||'•'} ${msg}`);
}

// ✅ Helper: isWAContextError — WhatsApp session/frame সম্পূর্ণ broken কিনা চেক করে
// এই error গুলো হলে reconnect দরকার
// এই function টা sendWA, route handlers এবং global error handlers সব জায়গায় ব্যবহার হয়
function isWAContextError(msg) {
  if (!msg) return false;
  return (
    msg.includes('Execution context was destroyed') ||
    msg.includes('Session closed') ||
    msg.includes('Target closed') ||
    msg.includes('Protocol error') ||
    msg.includes('Navigation timeout') ||
    msg.includes('detached Frame') ||
    msg.includes('Detached Frame') ||
    msg.includes('Cannot find context') ||
    msg.includes('context was destroyed') ||
    msg.includes('frame was detached')
    // ⚠️ NOTE: "Data passed to getter / id property" error এখানে নেই
    // ঐ error গুলো isStoreError() দিয়ে handle করা হয় — retry করলেই ঠিক হয়
  );
}


// ✅ Helper: isStoreError — WhatsApp Web internal store/timing error কিনা
// এই error গুলো সাধারণত transient (ক্ষণস্থায়ী) — retry করলেই কাজ করে
function isStoreError(msg) {
  if (!msg) return false;
  return (
    msg.includes('Data passed to getter must include an id property') ||
    msg.includes('include an id property') ||
    (msg.includes('got undefined') && msg.includes('getter'))
  );
}

// ✅ Helper: safeSendMessage — store error হলে store warm করে retry করে
// সরাসরি sendMessage — getNumberId ছাড়াই reliable
async function safeSendMessage(phone, content, opts) {
  const target = `${phone}@c.us`;

  for (let attempt = 1; attempt <= 5; attempt++) {
    try {
      return await waClient.sendMessage(target, content, opts || {});
    } catch(e) {
      const msg = e.message || '';

      // Session/frame completely broken → reconnect
      if (isWAContextError(msg) && !isStoreError(msg)) {
        addLog('error', `WhatsApp context broken (+${phone}) attempt ${attempt}: ${msg}`);
        waReady = false;
        if (!waReconnecting) scheduleReconnect(5000);
        throw e;
      }

      // Store timing error → store warm করে retry
      if (isStoreError(msg)) {
        if (attempt < 5) {
          const delay = attempt * 3000; // 3s, 6s, 9s, 12s
          addLog('warn', `Store timing (attempt ${attempt}/5) → ${delay/1000}s পর retry... (+${phone})`);
          // ✅ Store warm করো — WhatsApp Web-এর internal store refresh
          try {
            await waClient.pupPage.evaluate(() => {
              // Contact store refresh trigger করো
              if (window.Store && window.Store.Contact) {
                window.Store.Contact.gadd && window.Store.Contact.gadd({});
              }
            });
          } catch(_) {} // এটা fail হলেও চলবে
          await new Promise(r => setTimeout(r, delay));
          continue;
        }
        // ৫ বার retry করেও fail
        addLog('warn', `Store error ৫ বার retry করেও ব্যর্থ (+${phone})`);
        throw new Error(`WhatsApp সাময়িক সমস্যা — ১৫ সেকেন্ড পর আবার চেষ্টা করুন।`);
      }

      // অন্য error → সরাসরি throw
      throw e;
    }
  }
}






// ── Data helpers ───────────────────────────────────────────────
function loadSchedule() {
  try {
    const data = JSON.parse(fs.readFileSync(SCHED_FILE, 'utf-8'));
    data.settings = data.settings || {};
    data.settings.joinMeetMessage          = data.settings.joinMeetMessage          || 'আসসালামু আলাইকুম। এটা ক্লাসের লিংক — Global Islamic Care';
    data.settings.counselingMessage        = data.settings.counselingMessage        || 'আসসালামু আলাইকুম। কাউন্সেলিং লিংক — Global Islamic Care';
    data.settings.sendMessageMinutesBefore = data.settings.sendMessageMinutesBefore ?? 2;
    data.settings.joinMeetMinutesBefore    = data.settings.joinMeetMinutesBefore    ?? 0;
    data.tempClasses        = data.tempClasses        || [];
    data.counselingSessions = data.counselingSessions || [];
    return data;
  } catch(e) {
    // ✅ schedule.json corrupt বা missing হলে crash এর বদলে empty data return
    addLog('error', 'schedule.json লোড ব্যর্থ: ' + e.message + ' — খালি schedule দিয়ে চলবে।');
    return { classes: [], tempClasses: [], counselingSessions: [], settings: {
      joinMeetMessage: 'আসসালামু আলাইকুম। এটা ক্লাসের লিংক — Global Islamic Care',
      counselingMessage: 'আসসালামু আলাইকুম। কাউন্সেলিং লিংক — Global Islamic Care',
      sendMessageMinutesBefore: 2,
      joinMeetMinutesBefore: 0
    }};
  }
}
function saveSchedule(d)  { fs.writeFileSync(SCHED_FILE, JSON.stringify(d, null, 2), 'utf-8'); }
function loadSentLog()    { try { return JSON.parse(fs.readFileSync(SENT_LOG,'utf-8')); } catch { return []; } }
function appendSentLog(e) { const l=loadSentLog(); l.unshift(e); if(l.length>500)l.pop(); fs.writeFileSync(SENT_LOG,JSON.stringify(l,null,2),'utf-8'); }
function loadStudents()   { try { return JSON.parse(fs.readFileSync(STUDENTS,'utf-8')); } catch { return []; } }
function saveStudents(a)  { fs.writeFileSync(STUDENTS, JSON.stringify(a,null,2),'utf-8'); }
function loadHistory()    { try { return JSON.parse(fs.readFileSync(HISTORY,'utf-8')); } catch { return {}; } }
function saveHistory(h)   { fs.writeFileSync(HISTORY, JSON.stringify(h,null,2),'utf-8'); }
// ✅ Timezone-aware helpers — সব অপারেশন Asia/Dhaka timezoneএ
function getCurTime()  {
  return new Date().toLocaleTimeString('en-GB', { timeZone:'Asia/Dhaka', hour:'2-digit', minute:'2-digit', hour12:false });
}
function getCurDay()   {
  return new Date().toLocaleDateString('en-US',  { timeZone:'Asia/Dhaka', weekday:'long' });
}
function getCurDate()  {
  return new Date().toLocaleDateString('en-CA',  { timeZone:'Asia/Dhaka' }); // YYYY-MM-DD
}
function timeToMin(t)  { const [h,m]=t.split(':').map(Number); return h*60+m; }
function inWindow(cur,tgt,before,after) { const c=timeToMin(cur),t=timeToMin(tgt); let d=c-t; if(d<-720)d+=1440; if(d>720)d-=1440; return d>=-before&&d<=after; }
function todayKey(cls,tp) { return `${getCurDate()}_${tp}_${cls.studentName}_${cls.time}`; }

// ✅ দৈনিক reset বাদ দেওয়া হয়েছে — sentToday/joinedToday তে date-prefix আছে, তাই Reset ছাড়াই কাজ করবে।

// ✅ Load persisted sent/joined logs from disk
const SENT_TODAY_FILE = path.join(CLS_DIR, 'sent_today.json');
try {
  if (fs.existsSync(SENT_TODAY_FILE)) {
    const today = getCurDate();
    const data = JSON.parse(fs.readFileSync(SENT_TODAY_FILE, 'utf-8'));
    if (data.sent) {
      data.sent.filter(k => k && k.startsWith(today)).forEach(k => sentToday.add(k));
    }
    if (data.joined) {
      data.joined.filter(k => k && k.startsWith(today)).forEach(k => joinedToday.add(k));
    }
  }
} catch (e) {
  addLog('warn', 'Failed to load sent_today.json: ' + e.message);
}

function saveSentToday() {
  try {
    const today = getCurDate();
    // ✅ পুরনো দিনের entries মুছে ফেলো — file bloat বন্ধ করো
    for (const k of [...sentToday])  { if (!k.startsWith(today)) sentToday.delete(k); }
    for (const k of [...joinedToday]) { if (!k.startsWith(today)) joinedToday.delete(k); }
    const data = {
      sent: Array.from(sentToday),
      joined: Array.from(joinedToday)
    };
    fs.writeFileSync(SENT_TODAY_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (e) {
    addLog('warn', 'Failed to save sent_today.json: ' + e.message);
  }
}

function getMeetCode(url) {
  if (!url) return '';
  const match = url.match(/[a-z]{3}-[a-z]{4}-[a-z]{3}/i);
  return match ? match[0] : url;
}

async function isLinkAlreadySentInChat(phone, meetLink, classTimeStr) {
  if (!phone) return false;
  try {
    const chat = await waClient.getChatById(`${phone}@c.us`);
    if (!chat) return false;
    const messages = await chat.fetchMessages({ limit: 15 });
    const todayStr = getCurDate();
    const code = getMeetCode(meetLink);
    const classTimeMin = timeToMin(classTimeStr);
    
    for (const msg of messages) {
      // ✅ শুধুমাত্র আমাদের পক্ষ থেকে পাঠানো মেসেজ চেক করা হবে (fromMe)
      // Student নিজে লিংক পাঠালে সেটাকে "already sent" হিসেবে ধরা হবে না
      if (!msg.fromMe) continue;

      const msgDateObj = new Date(msg.timestamp * 1000);
      const msgDate = msgDateObj.toLocaleDateString('en-CA', { timeZone: 'Asia/Dhaka' });
      
      if (msgDate === todayStr) {
        if (msg.body && (msg.body.includes(meetLink) || (code && msg.body.includes(code)))) {
          const msgTimeStr = msgDateObj.toLocaleTimeString('en-GB', { timeZone: 'Asia/Dhaka', hour: '2-digit', minute: '2-digit', hour12: false });
          const msgTimeMin = timeToMin(msgTimeStr);
          
          let diff = msgTimeMin - classTimeMin;
          if (diff < -720) diff += 1440;
          if (diff > 720) diff -= 1440;
          
          // ✅ ক্লাসের ৬০ মিনিট আগে থেকে ৩০ মিনিট পর পর্যন্ত পাঠানো লিংক গ্রহণযোগ্য
          if (diff >= -60 && diff <= 30) {
            return true;
          }
        }
      }
    }
  } catch (e) {
    addLog('warn', `Failed to check chat history for +${phone}: ${e.message}`);
  }
  return false;
}


// ── Express ────────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
app.use(express.json({ limit: '50mb' }));
app.use((req,res,next) => {
  res.header('Access-Control-Allow-Origin','*');
  res.header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers','Content-Type,x-teacher-token');
  if(req.method==='OPTIONS') return res.sendStatus(200);
  next();
});

// ── Static tools ───────────────────────────────────────────────
app.use('/tools/report',   express.static(path.join(ROOT, '02 - Report Generator')));
app.use('/tools/invoice',  express.static(path.join(ROOT, '03 - Invoice Generator')));
app.use('/tools/cls-dash', express.static(path.join(CLS_DIR, 'dashboard')));

// ── API: Status ────────────────────────────────────────────────
app.get('/api/status', (req,res) => res.json({
  ready: waReady, status: waStatus, hasQR: !!waQR, qrData: waQR,
  time: getCurTime(), day: getCurDay(),   // ✅ Dhaka timezone
}));

// ── API: WhatsApp Status (সব route একই data দেয়) ──────────────
const statusHandler = (req,res) => res.json({ ready: waReady, status: waStatus, hasQR: !!waQR });
app.get('/api/wa-status',       statusHandler);
app.get('/api/cls/status',      (req,res) => res.json({ botRunning:true, whatsappReady:waReady, whatsappStatus:waStatus, hasQR:!!waQR, qrData:waQR, currentTime:getCurTime(), currentDay:getCurDay(), isJoiningMeet }));
app.get('/api/report/status',   (req,res) => res.json({ ready:waReady, status:waStatus, hasQR:!!waQR }));
app.get('/api/report/wa-status',statusHandler);

app.post('/api/reset-wa', async (req,res) => {
  addLog('warn','⚠️ হোয়াটসঅ্যাপ সেশন রিসেট করা হচ্ছে...');
  waReady=false; waStatus='connecting'; waQR=null;
  try{ await waClient.destroy(); }catch(_){}
  try{ fs.rmSync(AUTH_PATH, { recursive: true, force: true }); }catch(_){}
  try{ fs.rmSync(CACHE_PATH, { recursive: true, force: true }); }catch(_){}
  try{ fs.unlinkSync(QR_FILE); }catch(_){}
  res.json({success:true, message:'Session reset. New QR code generating...'});
  setTimeout(() => {
    waClient.initialize().catch(e => addLog('error', 'WhatsApp initialize ব্যর্থ: ' + e.message));
  }, 2000);
});

// ── API: QR Image (একটাই) ─────────────────────────────────────
const qrHandler = (req,res) => { if(fs.existsSync(QR_FILE)) res.sendFile(QR_FILE); else res.status(404).json({error:'QR not ready'}); };
app.get('/api/qr-image',        qrHandler);
app.get('/api/cls/qr-image',    qrHandler);
app.get('/api/report/qr-image', qrHandler);

// ── API: Logs ──────────────────────────────────────────────────
const logHandler = (req,res) => { const s=req.query.since; res.json(s ? waLogs.filter(l=>l.time>s) : waLogs.slice(-80)); };
app.get('/api/logs',        logHandler);
app.get('/api/cls/logs',    logHandler);
app.get('/api/report/logs', logHandler);

// ── API: Schedule ──────────────────────────────────────────────
app.get('/api/schedule',      (req,res) => { try{res.json(loadSchedule());}catch(e){res.status(500).json({error:e.message});} });
app.post('/api/schedule',     (req,res) => { try{saveSchedule(req.body);res.json({success:true});}catch(e){res.status(500).json({error:e.message});} });
app.get('/api/cls/schedule',  (req,res) => { try{res.json(loadSchedule());}catch(e){res.status(500).json({error:e.message});} });
app.post('/api/cls/schedule', (req,res) => { try{saveSchedule(req.body);res.json({success:true});}catch(e){res.status(500).json({error:e.message});} });
app.post('/api/cls/test-join', (req, res) => {
  const url = req.body.url || 'https://meet.google.com';
  const name = req.body.studentName || 'টেস্ট ক্লাস';
  joinMeet({ studentName: name, meetLink: url });
  res.json({ success: true, message: 'ব্রাউজারে নতুন ট্যাব ওপেন করার কমান্ড পাঠানো হয়েছে।' });
});

// ── API: Report Data ───────────────────────────────────────────
// ── API: Students (active only by default) ───────────────────────────
app.get('/api/students', (req,res) => {
  try {
    const all = loadStudents();
    // শুধু active students (alumni নয়)
    res.json(all.filter(s => !s.alumni));
  } catch(e) { res.status(500).json({error:e.message}); }
});
app.post('/api/students', (req,res) => {
  try { saveStudents(req.body.students); res.json({success:true}); }
  catch(e) { res.status(500).json({error:e.message}); }
});

// ── API: Archive Student (alumni করুন) ───────────────────────────────
app.post('/api/students/:id/archive', (req, res) => {
  try {
    const all = loadStudents();
    const idx = all.findIndex(s => s.id === req.params.id);
    if (idx < 0) return res.status(404).json({ error: 'Student পাওয়া যায়নি।' });
    all[idx].alumni = true;
    all[idx].archivedAt = getCurDate();
    saveStudents(all);
    addLog('info', `Student পূর্বতন তালিকায় সরানো হয়েছে: ${all[idx].name}`);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── API: Restore Alumni Student (ফিরিয়ে আনুন) ───────────────────────
app.post('/api/students/:id/restore', (req, res) => {
  try {
    const all = loadStudents();
    const idx = all.findIndex(s => s.id === req.params.id);
    if (idx < 0) return res.status(404).json({ error: 'Student পাওয়া যায়নি।' });
    all[idx].alumni = false;
    delete all[idx].archivedAt;
    saveStudents(all);
    addLog('info', `Alumni Student সক্রিয় তালিকায় ফিরিয়ে আনা হয়েছে: ${all[idx].name}`);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── API: List Alumni Students ─────────────────────────────────────────
app.get('/api/students/alumni', (req, res) => {
  try {
    const all = loadStudents();
    res.json(all.filter(s => s.alumni === true));
  } catch(e) { res.status(500).json({ error: e.message }); }
});

app.delete('/api/students/alumni/:id', (req, res) => {
  try {
    let all = loadStudents();
    all = all.filter(s => s.id !== req.params.id);
    saveStudents(all);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── API: Student History ──────────────────────────────────────────────
app.get('/api/student-history/:id',     (req,res) => { const h=loadHistory(); res.json(h[req.params.id]||[]); });
app.post('/api/student-history/:id',    (req,res) => { try{const h=loadHistory();h[req.params.id]=req.body.history;saveHistory(h);res.json({success:true});}catch(e){res.status(500).json({error:e.message});} });
app.delete('/api/student-history/:id',  (req,res) => { try{const h=loadHistory();delete h[req.params.id];saveHistory(h);res.json({success:true});}catch(e){res.status(500).json({error:e.message});} });

// ── API: Sent Log ─────────────────────────────────────────────
app.get('/api/sent-log', (req,res) => res.json(loadSentLog()));

// ════════════════════════════════════════════════════════════════
//  PAYMENT / INCOME TRACKER
// ════════════════════════════════════════════════════════════════
const PAYMENTS_FILE = path.join(__dirname, 'payments.json');
function loadPayments() {
  try {
    if (!fs.existsSync(PAYMENTS_FILE)) return [];
    return JSON.parse(fs.readFileSync(PAYMENTS_FILE, 'utf-8'));
  } catch(e) { return []; }
}
function savePayments(arr) {
  fs.writeFileSync(PAYMENTS_FILE, JSON.stringify(arr, null, 2), 'utf-8');
}

// Get all payments (with optional month filter: ?month=2026-08)
app.get('/api/payments', (req, res) => {
  try {
    const all = loadPayments();
    const { month } = req.query;
    if (month) {
      res.json(all.filter(p => p.date && p.date.startsWith(month)));
    } else {
      res.json(all);
    }
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Add a payment record
app.post('/api/payments', (req, res) => {
  try {
    const { studentId, studentName, amount, month, note } = req.body;
    if (!studentId || !amount || !month)
      return res.status(400).json({ error: 'studentId, amount ও month আবশ্যক।' });
    const payments = loadPayments();
    // Check if already paid this month for this student
    const existing = payments.find(p => p.studentId === studentId && p.month === month);
    if (existing)
      return res.status(400).json({ error: `${studentName || studentId} এই মাসে ইতিমধ্যে পেমেন্ট করেছেন।` });
    const payment = {
      id: 'pay_' + Date.now(),
      studentId,
      studentName: studentName || '',
      amount: Number(amount),
      month, // YYYY-MM format
      date: getCurDate(),
      note: note || '',
      createdAt: new Date().toISOString()
    };
    payments.push(payment);
    savePayments(payments);
    addLog('success', `পেমেন্ট রেকর্ড: ${studentName} — ৳${amount} (${month})`);
    res.json({ success: true, payment });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Delete a payment record
app.delete('/api/payments/:id', (req, res) => {
  try {
    let payments = loadPayments();
    const found = payments.find(p => p.id === req.params.id);
    if (!found) return res.status(404).json({ error: 'Payment পাওয়া যায়নি।' });
    payments = payments.filter(p => p.id !== req.params.id);
    savePayments(payments);
    res.json({ success: true });
  } catch(e) { res.status(500).json({ error: e.message }); }
});

// Monthly summary: total income, paid students, pending students
app.get('/api/payments/summary/:month', (req, res) => {
  try {
    const { month } = req.params; // YYYY-MM
    const payments = loadPayments().filter(p => p.month === month);
    const students = loadStudents().filter(s => !s.alumni);
    const paidIds = new Set(payments.map(p => p.studentId));
    const totalIncome = payments.reduce((sum, p) => sum + (p.amount || 0), 0);
    const pendingStudents = students.filter(s => !paidIds.has(s.id));
    res.json({
      month,
      totalIncome,
      paidCount: payments.length,
      pendingCount: pendingStudents.length,
      totalStudents: students.length,
      payments,
      pendingStudents: pendingStudents.map(s => ({ id: s.id, name: s.name, fee: s.fee || 0 })),
      expectedTotal: students.reduce((sum, s) => sum + (s.fee || 0), 0)
    });
  } catch(e) { res.status(500).json({ error: e.message }); }
});



// ── API: Gmail Login ───────────────────────────────────────────
const gmailLoginHandler = (req,res) => {
  const cp = ['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
    'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe'].find(p=>fs.existsSync(p));
  if(!cp) return res.status(500).json({error:'Chrome খুঁজে পাওয়া যায়নি।'});
  exec(`"${cp}" --user-data-dir="${BOT_PROFILE_DIR}" "https://accounts.google.com/" --no-first-run`);
  res.json({success:true});
};
app.post('/api/gmail-login', gmailLoginHandler);
app.post('/api/cls/gmail-login', gmailLoginHandler);

// ── API: Send PDF Report / Invoice ────────────────────────────
app.post('/api/send-report-pdf', async (req,res) => {
  try {
    const { phone, phone2, pdfBase64, studentName, filename, caption: customCaption } = req.body;
    if(!waReady) return res.status(503).json({success:false, error:'WhatsApp সংযুক্ত নেই। QR কোড স্ক্যান করুন।'});
    if(!phone||!pdfBase64) return res.status(400).json({success:false, error:'phone ও pdfBase64 আবশ্যক।'});
    
    const cleanPhone = String(phone).replace(/\D/g,'');
    if (!cleanPhone || cleanPhone.length < 7)
      return res.status(400).json({success:false, error:'ফোন নম্বর সঠিক নয়।'});

    const pdfName    = filename || `Report_${(studentName||'Student').replace(/\s+/g,'_')}.pdf`;
    const media      = new MessageMedia('application/pdf', pdfBase64, pdfName);
    const defaultCaption = `📋 *Daily Progress Report*\n👤 Student: *${studentName||'—'}*\n🏫 *Global Islamic Care*`;
    const caption    = (customCaption && String(customCaption).trim()) ? String(customCaption).trim() : defaultCaption;
    
    // ✅ FIX: safeSendMessage — PDF-এর জন্য sendMediaAsDocument: true নিশ্চিত করো
    await safeSendMessage(cleanPhone, media, { caption, sendMediaAsDocument: true });
    appendSentLog({ studentName:studentName||'—', phone:cleanPhone, filename:pdfName,
      dateRaw:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Dhaka'}),
      sentAt:new Date().toLocaleString('en-US',{timeZone:'Asia/Dhaka'}), success:true });
    addLog('success',`PDF পাঠানো হয়েছে → ${studentName} (+${cleanPhone})`);

    // Send to secondary phone if provided and different
    let phone2Result = null;
    if (phone2) {
      const cleanPhone2 = String(phone2).replace(/\D/g,'');
      if (cleanPhone2 && cleanPhone2 !== cleanPhone) {
        try {
          await safeSendMessage(cleanPhone2, media, { caption, sendMediaAsDocument: true });
          addLog('success',`PDF পাঠানো হয়েছে (২য় Number) → ${studentName} (+${cleanPhone2})`);
          phone2Result = { ok: true };
        } catch(e2) {
          addLog('warn',`২য় Numberে PDF পাঠাতে ব্যর্থ → ${studentName} (+${cleanPhone2}): ${e2.message}`);
          phone2Result = { ok: false, error: e2.message };
        }
      }
    }

    res.json({success:true, message:`✅ PDF পাঠানো হয়েছে → ${studentName}`, phone2Result});
  } catch(err) {
    // ✅ detached Frame / context error — reconnect করো
    if (isWAContextError(err.message)) {
      addLog('error', `WhatsApp frame detached (PDF send) — reconnect হচ্ছে: ${err.message}`);
      waReady = false;
      if (!waReconnecting) scheduleReconnect(5000);
      appendSentLog({ studentName:req.body.studentName||'—', phone:req.body.phone||'—',
        filename:req.body.filename||'—', dateRaw:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Dhaka'}),
        sentAt:new Date().toLocaleString('en-US',{timeZone:'Asia/Dhaka'}), success:false, error:'WhatsApp সংযোগ পুনরায় স্থাপন হচ্ছে' });
      return res.status(503).json({success:false, error:'⚠️ WhatsApp সংযোগ সাময়িকভাবে বিচ্ছিন্ন হয়েছে। ১০-১৫ সেকেন্ড পর আবার চেষ্টা করুন।'});
    }
    // ✅ "number not on WhatsApp" বা অন্য error — স্পষ্ট message দাও
    addLog('error', `PDF পাঠাতে ব্যর্থ → ${req.body.studentName||'?'}: ${err.message}`);
    appendSentLog({ studentName:req.body.studentName||'—', phone:req.body.phone||'—',
      filename:req.body.filename||'—', dateRaw:new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Dhaka'}),
      sentAt:new Date().toLocaleString('en-US',{timeZone:'Asia/Dhaka'}), success:false, error:err.message });
    res.status(500).json({success:false, error:err.message});
  }
});


// ── API: Send Custom WhatsApp Message ────────────────────────
app.post('/api/send-message', async (req,res) => {
  try {
    const { message, targets } = req.body;
    if(!waReady) return res.status(503).json({success:false, error:'WhatsApp সংযুক্ত নেই। QR কোড স্ক্যান করুন।'});
    if(!message || !message.trim()) return res.status(400).json({success:false, error:'মেসেজ খালি!'});
    const students = loadStudents();
    let list = students;
    if(targets && targets !== 'all' && Array.isArray(targets) && targets.length > 0) {
      list = students.filter(s => targets.includes(s.id));
    }
    if(!list.length) return res.status(400).json({success:false, error:'কোনো প্রাপক নির্বাচিত নেই!'});
    const results = [];
    let waContextBroken = false; // context error হলে আর চেষ্টা করবো না
    for(const s of list) {
      if (waContextBroken) {
        results.push({ name: s.name, phone: s.phone, ok: false, error: 'WhatsApp সংযোগ সমস্যা' });
        continue;
      }
      const phones = [s.phone, s.phone2].filter(Boolean).map(p=>String(p).replace(/\D/g,''));
      const sentP = new Set();
      let ok = false;
      let errMsg = '';
      for(const ph of phones) {
        if(!ph || sentP.has(ph)) continue;
        try {
          await safeSendMessage(ph, message);
          sentP.add(ph);
          ok = true;
          addLog('success', `মেসেজ পাঠানো → ${s.name} (+${ph})`);
        } catch(e) {
          errMsg = e.message;
          addLog('error', `মেসেজ ব্যর্থ → ${s.name} (+${ph}): ${e.message}`);
          if (isWAContextError(e.message)) {
            waReady = false;
            if (!waReconnecting) scheduleReconnect(5000);
            waContextBroken = true;
            break; // phone loop বন্ধ
          }
        }
      }
      results.push({ name: s.name, phone: s.phone, ok, error: ok ? undefined : errMsg });
    }
    const sent = results.filter(r=>r.ok).length;
    res.json({ success:true, results, summary:`${sent}/${results.length} জনকে মেসেজ পাঠানো হয়েছে।` });
  } catch(err) {
    res.status(500).json({success:false, error:err.message});
  }
});


// ══════════════════════════════════════════════════════════════
//  TEACHER API ROUTES
// ══════════════════════════════════════════════════════════════

// ── Teacher Login ────────────────────────────────────────────
app.post('/api/teacher/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password)
    return res.status(400).json({ success: false, error: 'Username ও Password দিন।' });
  const teachers = loadTeachers();
  const teacher = teachers.find(t => t.username === username.trim());
  if (!teacher || !verifyPassword(password, teacher.passwordHash))
    return res.status(401).json({ success: false, error: 'Username বা Password ভুল।' });
  const token = createTeacherToken(teacher.id);
  addLog('info', `শিক্ষক লগইন: ${teacher.name} (${teacher.username})`);
  res.json({ success: true, token, teacher: { id: teacher.id, name: teacher.name, username: teacher.username, subject: teacher.subject || '' } });
});

// ── Teacher Logout ───────────────────────────────────────────
app.post('/api/teacher/logout', (req, res) => {
  const token = req.headers['x-teacher-token'];
  if (token) invalidateTeacherToken(token);
  res.json({ success: true });
});

// ── Teacher: Get own info ────────────────────────────────────
app.get('/api/teacher/me', teacherAuth, (req, res) => {
  const t = req.teacher;
  res.json({ id: t.id, name: t.name, username: t.username, subject: t.subject || '', studentIds: t.studentIds || [] });
});

// ── Teacher: Get own students ────────────────────────────────
app.get('/api/teacher/students', teacherAuth, (req, res) => {
  const teacher = req.teacher;
  const allStudents = loadStudents();
  const myStudents = (teacher.studentIds && teacher.studentIds.length > 0)
    ? allStudents.filter(s => teacher.studentIds.includes(s.id))
    : [];
  res.json(myStudents);
});

// ── Teacher: Get schedule (read-only) ───────────────────────
app.get('/api/teacher/schedule', teacherAuth, (req, res) => {
  try { res.json(loadSchedule()); } catch(e) { res.status(500).json({ error: e.message }); }
});

// ── ADMIN: List all teachers ─────────────────────────────────
app.get('/api/admin/teachers', (req, res) => {
  const teachers = loadTeachers().map(t => ({
    id: t.id, name: t.name, username: t.username,
    subject: t.subject || '', studentIds: t.studentIds || [],
    createdAt: t.createdAt
  }));
  res.json(teachers);
});

// ── ADMIN: Create teacher ────────────────────────────────────
app.post('/api/admin/teachers', (req, res) => {
  const { name, username, password, subject, studentIds } = req.body;
  if (!name || !username || !password)
    return res.status(400).json({ error: 'নাম, Username ও Password আবশ্যক।' });
  const teachers = loadTeachers();
  if (teachers.find(t => t.username === username.trim()))
    return res.status(400).json({ error: 'এই Username ইতিমধ্যে ব্যবহৃত হচ্ছে।' });
  const teacher = {
    id: 'teacher_' + Date.now(),
    name: name.trim(),
    username: username.trim(),
    passwordHash: hashPassword(password),
    subject: subject || '',
    studentIds: studentIds || [],
    createdAt: getCurDate()
  };
  teachers.push(teacher);
  saveTeachers(teachers);
  addLog('success', `নতুন শিক্ষক যোগ: ${teacher.name} (${teacher.username})`);
  res.json({ success: true, teacher: { id: teacher.id, name: teacher.name, username: teacher.username, subject: teacher.subject, studentIds: teacher.studentIds, createdAt: teacher.createdAt } });
});

// ── ADMIN: Update teacher ────────────────────────────────────
app.put('/api/admin/teachers/:id', (req, res) => {
  const { name, username, password, subject, studentIds } = req.body;
  const teachers = loadTeachers();
  const idx = teachers.findIndex(t => t.id === req.params.id);
  if (idx < 0) return res.status(404).json({ error: 'শিক্ষক পাওয়া যায়নি।' });
  // Check username uniqueness (except self)
  if (username && teachers.find(t => t.username === username.trim() && t.id !== req.params.id))
    return res.status(400).json({ error: 'এই Username ইতিমধ্যে ব্যবহৃত হচ্ছে।' });
  if (name) teachers[idx].name = name.trim();
  if (username) teachers[idx].username = username.trim();
  if (password) teachers[idx].passwordHash = hashPassword(password);
  if (subject !== undefined) teachers[idx].subject = subject;
  if (studentIds !== undefined) teachers[idx].studentIds = studentIds;
  saveTeachers(teachers);
  addLog('info', `শিক্ষক আপডেট: ${teachers[idx].name}`);
  res.json({ success: true });
});

// ── ADMIN: Delete teacher ────────────────────────────────────
app.delete('/api/admin/teachers/:id', (req, res) => {
  let teachers = loadTeachers();
  const teacher = teachers.find(t => t.id === req.params.id);
  if (!teacher) return res.status(404).json({ error: 'শিক্ষক পাওয়া যায়নি।' });
  teachers = teachers.filter(t => t.id !== req.params.id);
  saveTeachers(teachers);
  // Invalidate all sessions for this teacher
  for (const [tok, sess] of teacherSessions.entries()) {
    if (sess.teacherId === req.params.id) teacherSessions.delete(tok);
  }
  addLog('info', `শিক্ষক মুছে ফেলা হয়েছে: ${teacher.name}`);
  res.json({ success: true });
});

// ── Teacher Pages ────────────────────────────────────────────
app.get('/teacher/login', (req, res) => res.send(TEACHER_LOGIN_PAGE));
app.get('/teacher',       (req, res) => res.send(TEACHER_DASHBOARD));
// redirect /teacher/ → /teacher
app.get('/teacher/',      (req, res) => res.redirect('/teacher'));

// ── Dashboards ─────────────────────────────────────────────────
app.get('/',                 (req,res) => res.send(DASHBOARD));
app.get('/report-dashboard', (req,res) => res.send(REPORT_DASH));

// ── WhatsApp: একটাই Client সব কাজের জন্য ─────────────────────
const chrome64 = 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe';
const cp = fs.existsSync(chrome64) ? chrome64 : undefined;


const waClient = new Client({
  // ✅ FIX: webVersionCache 'remote' বাদ দেওয়া হয়েছে।
  // Remote GitHub URL পুরনো বা unavailable হলে session বারবার disconnect হতো।
  // WhatsApp Web নিজেই সঠিক version লোড করবে।
  authStrategy: new LocalAuth({ dataPath: AUTH_PATH, clientId: 'gic-main' }),
  userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
  puppeteer: {
    headless: true, // ✅ Headless true থাকবে
    executablePath: cp || undefined, // ✅ Chrome-এর ওরিজিনাল codecs প্রয়োজন, তাই custom path ফেরত আনা হলো
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--no-first-run',
      '--no-zygote',
      '--disable-extensions',
      '--disable-accelerated-2d-canvas',
      '--disable-gl-drawing-for-tests',
      '--disable-component-update',
      '--disable-features=Translate,VizDisplayCompositor',
      '--disable-background-networking',
      '--disable-sync',
      '--metrics-recording-only',
      '--no-default-browser-check',
      '--disable-background-timer-throttling',
      '--disable-renderer-backgrounding',
      `--disk-cache-dir=${CACHE_PATH}`,
      '--disk-cache-size=67108864'
    ]
  }
});

// ✅ WhatsApp client-level error handler — process crash বন্ধ করে
waClient.on('loading_screen', (percent, message) => {
  addLog('info', `⏳ WhatsApp লোডিং: ${percent}% ${message ? '(' + message + ')' : ''}`);
});

waClient.on('error', err => {
  addLog('error', 'WhatsApp error: ' + err.message);
});

waClient.on('qr', qr => {
  waQR = qr; waStatus = 'qr';
  console.log('\n[GIC] 📱 QR কোড তৈরি হয়েছে — নিচে দেখুন এবং স্ক্যান করুন:\n');
  qrcode.generate(qr, { small: true });
  // ✅ Local QR image — internet ছাড়াই কাজ করে (qrcode package ব্যবহার করে)
  qrcodeImage.toFile(QR_FILE, qr, { width: 300, margin: 2 }, (err) => {
    if (err) addLog('warn', 'QR image সেভ হয়নি: ' + err.message);
    else addLog('info', '📷 QR image সেভ হয়েছে — Dashboard-এ দেখুন');
  });
});

let authWatchdog = null;
let isReadyEmitted = false;

waClient.on('ready', () => {
  if (isReadyEmitted) return;
  isReadyEmitted = true;
  if (authWatchdog) { clearInterval(authWatchdog); authWatchdog = null; }
  waStatus='ready'; waQR=null;
  try{ fs.unlinkSync(QR_FILE); }catch(e){}
  if (waWarmupTimer) { clearTimeout(waWarmupTimer); waWarmupTimer = null; }
  addLog('info', '⏳ WhatsApp সংযুক্ত — প্রস্তুত হচ্ছে...');
  waWarmupTimer = setTimeout(() => {
    waWarmupTimer = null;
    waReady = true;
    addLog('success', '✅ WhatsApp সম্পূর্ণ প্রস্তুত! CLS Bot + Report Bot চালু।');
  }, 3000);
});

waClient.on('authenticated', () => {
  addLog('info','🔐 WhatsApp Authentication সফল — সেশন সেভ হয়েছে। চ্যাট ডেটা সিঙ্ক হচ্ছে...');
  // ✅ Watchdog: যদি wwebjs ready ইভেন্ট মিস করে বা দেরি করে, তবে ব্যাকগ্রাউন্ডে চেক করে ready করবে
  if (authWatchdog) clearInterval(authWatchdog);
  authWatchdog = setInterval(async () => {
    if (waReady || waStatus === 'ready') {
      clearInterval(authWatchdog);
      authWatchdog = null;
      return;
    }
    try {
      if (waClient.pupPage) {
        const isLoaded = await waClient.pupPage.evaluate(() => {
          return typeof window.WWebJS !== 'undefined' || !!document.querySelector('#pane-side, [data-testid="chat-list"]');
        });
        if (isLoaded) {
          addLog('info', 'ℹ️ WhatsApp Web সক্রিয় শনাক্ত হয়েছে — স্বয়ংক্রিয়ভাবে রেডি করা হচ্ছে...');
          clearInterval(authWatchdog);
          authWatchdog = null;
          if (!waClient.info) {
            try {
              const ClientInfo = require('whatsapp-web.js/src/structures/ClientInfo');
              const infoData = await waClient.pupPage.evaluate(() => {
                const conn = window.require('WAWebConnModel')?.Conn?.serialize() || {};
                const me = window.require('WAWebUserPrefsMeUser');
                const wid = me?.getMaybeMePnUser() || me?.getMaybeMeLidUser();
                return { ...conn, wid };
              });
              waClient.info = new ClientInfo(waClient, infoData);
            } catch (_) {}
          }
          waClient.emit('ready');
        }
      }
    } catch (_) {}
  }, 4000);
});

waClient.on('auth_failure', async m => {
  isReadyEmitted = false;
  waReady=false; waStatus='auth_failure';
  if (waWarmupTimer) { clearTimeout(waWarmupTimer); waWarmupTimer = null; } // warmup cancel
  addLog('error','Authentication ব্যর্থ: '+m+' — সেশন পরিষ্কার করা হচ্ছে...');
  try { await waClient.destroy(); } catch(_) {}
  try { fs.rmSync(AUTH_PATH, { recursive: true, force: true }); } catch(_) {}
  try { fs.rmSync(CACHE_PATH, { recursive: true, force: true }); } catch(_) {}
  scheduleReconnect(5000);
});

waClient.on('disconnected', async r => {
  isReadyEmitted = false;
  waReady=false; waStatus='disconnected';
  if (waWarmupTimer) { clearTimeout(waWarmupTimer); waWarmupTimer = null; } // warmup cancel
  addLog('warn','বিচ্ছিন্ন: '+r+' — ১০ সেকেন্ড পর পুনরায় সংযোগ চেষ্টা করবে...');
  // ✅ FIX: শুধুমাত্র LOGOUT হলে session মুছবে।
  // অন্য কারণে (network drop, WhatsApp server timeout ইত্যাদি) disconnect হলে
  // session অক্ষুণ্ণ রেখে QR ছাড়াই reconnect হবে — আবার QR scan করতে হবে না।
  if (r === 'LOGOUT') {
    addLog('warn', 'LOGOUT শনাক্ত — session পরিষ্কার করা হচ্ছে। নতুন QR scan করতে হবে।');
    try { fs.rmSync(AUTH_PATH, { recursive: true, force: true }); } catch(_) {}
    try { fs.rmSync(CACHE_PATH, { recursive: true, force: true }); } catch(_) {}
  } else {
    addLog('info', `Disconnect কারণ: "${r}" — session রেখে reconnect করছি (QR লাগবে না)।`);
  }
  scheduleReconnect(10000);
});

// ✅ Proper reconnect — আগে destroy করে তারপর নতুন করে initialize
let waShuttingDown = false; // ✅ Bug fix: SIGINT-এ reconnect loop বন্ধ করার জন্য flag
function scheduleReconnect(delayMs) {
  if (waReconnecting) return; // ডাবল reconnect বন্ধ
  if (waShuttingDown) return; // ✅ Bug fix: shutdown হলে reconnect করবে না
  waReconnecting = true;
  setTimeout(async () => {
    if (waShuttingDown) { waReconnecting = false; return; } // ✅ shutdown check inside timer
    addLog('info','পুনরায় সংযোগ হচ্ছে...');
    let succeeded = false;
    try {
      try { await waClient.destroy(); } catch(_) {} // আগের session বন্ধ করুন
      await new Promise(r => setTimeout(r, 3000));   // একটু বেশি অপেক্ষা করুন
      if (waShuttingDown) { waReconnecting = false; return; } // ✅ double-check after delay
      await waClient.initialize();
      succeeded = true;
    } catch(e) {
      addLog('error','Reconnect ব্যর্থ: '+e.message);
    }
    waReconnecting = false; // ✅ always reset before potential retry
    if (!succeeded && !waShuttingDown) {
      addLog('warn','৩০ সেকেন্ড পর আবার সংযোগ চেষ্টা হবে...');
      scheduleReconnect(30000); // ✅ retry with longer delay
    }
  }, delayMs);
}

// ── CLS Schedule Logic ─────────────────────────────────────────
async function sendWA(cls, msg) {
  if(!waReady) { addLog('warn','WhatsApp প্রস্তুত নয় — message skip'); return; }
  if(!cls.whatsappNumber) { addLog('warn',`WhatsApp Number নেই: ${cls.studentName} — skip`); return; }
  const phone1 = String(cls.whatsappNumber).replace(/\D/g,'');
  if(!phone1) { addLog('warn',`অবৈধ Number: ${cls.studentName} — skip`); return; }

  const sentPhones = new Set();

  // ── Primary phone ──────────────────────────────────────────
  try {
    await safeSendMessage(phone1, msg);
    addLog('success',`মেসেজ পাঠানো → ${cls.studentName} (+${phone1})`);
    sentPhones.add(phone1);
  } catch(e) {
    addLog('error',`মেসেজ ব্যর্থ → ${cls.studentName} (+${phone1}): ${e.message}`);
    // safeSendMessage ইতিমধ্যে reconnect handle করেছে — এখানে কিছু করতে হবে না
  }

  // ── Secondary phone (যদি থাকে) ────────────────────────────
  if(cls.whatsappNumber2) {
    const phone2 = String(cls.whatsappNumber2).replace(/\D/g,'');
    if(phone2 && !sentPhones.has(phone2)) {
      try {
        await safeSendMessage(phone2, msg);
        sentPhones.add(phone2);
        addLog('success',`মেসেজ পাঠানো (২য় Number) → ${cls.studentName} (+${phone2})`);
      } catch(e) {
        addLog('warn', `২য় Numberে মেসেজ ব্যর্থ → ${cls.studentName} (+${phone2}): ${e.message}`);
      }
    }
  }
}


async function closeMeetBrowser() {
  if(!activeMeetBrowser) return;
  const b=activeMeetBrowser; activeMeetBrowser=null;
  try { if(b.isConnected()) await b.close(); } catch(e){}
  await new Promise(r=>setTimeout(r,1500));
}

async function tryConnectChromeAndJoin(url) {
  try {
    const isPortOpen = await new Promise((resolve) => {
      const req = http.get('http://127.0.0.1:9222/json/version', { timeout: 300 }, (res) => {
        resolve(res.statusCode === 200);
      });
      req.on('error', () => resolve(false));
      req.on('timeout', () => { req.destroy(); resolve(false); });
    });

    if (!isPortOpen) return false;

    const browser = await puppeteer.connect({
      browserURL: 'http://127.0.0.1:9222',
      defaultViewport: null
    });

    const page = await browser.newPage();
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 });

    setTimeout(async () => {
      try {
        const joinSelectors = [
          'button[jsname="CQylAd"]',
          '[aria-label="Join now"]',
          '[aria-label="Ask to join"]',
          '[aria-label="এখন যোগ দিন"]',
          '[aria-label="যোগ দেওয়ার অনুরোধ করুন"]',
          '[data-idom-class*="nUpftc"]',
          '[jsname="Qx7uuf"]'
        ];
        for (const sel of joinSelectors) {
          const b = await page.$(sel);
          if (b) { await b.click(); break; }
        }
      } catch (_) {}
      try { browser.disconnect(); } catch (_) {}
    }, 4000);

    return true;
  } catch (_) {
    return false;
  }
}

async function joinMeet(cls) {
  if (isJoiningMeet) return;
  isJoiningMeet = true;
  try {
    const url = cls.meetLink;
    if (!url) {
      addLog('warn', `Meet লিংক পাওয়া যায়নি: ${cls.studentName}`);
      return;
    }
    addLog('info', `Meet ওপেন ও জয়েন প্রক্রিয়া শুরু (${cls.studentName}): ${url}`);

    // ১. যদি Chrome রিমোট ডিবাগিং মোডে (port 9222) চালু থাকে, সরাসরি কানেক্ট হয়ে জয়েন করবে
    const cdpSuccess = await tryConnectChromeAndJoin(url);
    if (!cdpSuccess) {
      // ২. সাধারণ মোড: ব্রাউজারে নতুন ট্যাব হিসেবে ওপেন করবে
      exec(`start "" "${url}"`, (err) => {
        if (err) {
          addLog('error', `Meet ট্যাব ওপেন ব্যর্থ: ${err.message}`);
        } else {
          addLog('success', `ব্রাউজারে Meet নতুন ট্যাবে ওপেন হয়েছে: ${cls.studentName}`);
        }
      });
    } else {
      addLog('success', `চলমান Chrome-এ নতুন ট্যাব খুলে অটো-জয়েন করা হচ্ছে: ${cls.studentName}`);
    }
  } catch (e) {
    addLog('error', `Meet error: ${e.message}`);
  } finally {
    setTimeout(() => { isJoiningMeet = false; }, 5000);
  }
}

async function checkSchedule() {
  if(isCheckingSchedule) return;
  isCheckingSchedule = true;
  
  try {
    let sched; try{sched=loadSchedule();}catch(e){return;}
    const {classes=[],tempClasses=[],counselingSessions=[],settings={}}=sched;
    const cur=getCurTime(), day=getCurDay(), today=getCurDate();
    const sb=settings.sendMessageMinutesBefore||0, jb=settings.joinMeetMinutesBefore||0;
    
    // ── ১. নিয়মিত ক্লাস ──
    for(const c of classes){
      if(c.enabled===false||!c.days?.includes(day)) continue;
      const sk=todayKey(c,'msg');
      const jk=todayKey(c,'join');

      // (A) WhatsApp লিংক পাঠানো (ক্লাস শুরুর ৫ মিনিট পার হলে আর পাঠাবে না)
      if(waReady && inWindow(cur,c.time,sb,5) && !sentToday.has(sk)){
        if(!c.whatsappNumber) {
          addLog('warn',`[Class] WhatsApp Number নেই: ${c.studentName} — skip`);
          sentToday.add(sk);
          saveSentToday();
        } else {
          const phone1 = String(c.whatsappNumber).replace(/\D/g,'');
          if(!phone1) {
            addLog('warn',`[Class] অবৈধ Number: ${c.studentName} — skip`);
            sentToday.add(sk);
            saveSentToday();
          } else {
            const alreadySent = await isLinkAlreadySentInChat(phone1, c.meetLink, c.time);
            if(alreadySent) {
              addLog('info', `Link already sent manually to ${c.studentName} (+${phone1}) for class at ${c.time}, skipping auto-send.`);
              sentToday.add(sk);
              saveSentToday();
            } else {
              sentToday.add(sk);
              saveSentToday();
              await sendWA(c,`${settings.joinMeetMessage}\n${c.meetLink}`);
            }
          }
        }
      }

      // (B) Google Meet ওপেন (৫ মিনিট পর্যন্ত সক্রিয় থাকবে)
      if(inWindow(cur,c.time,jb,5) && !joinedToday.has(jk)){
        joinedToday.add(jk);
        saveSentToday();
        joinMeet(c).catch(()=>{});
      }
    }

    // ── ২. টেম্পোরারি ক্লাস ──
    for(const tc of tempClasses){
      if(tc.enabled===false||tc.date!==today) continue;
      const cls={studentName:tc.studentName,whatsappNumber:tc.whatsappNumber,whatsappNumber2:tc.whatsappNumber2||null,meetLink:tc.meetLink,time:tc.time};
      const sk=`${today}_temp_msg_${tc.studentName}_${tc.time}`;
      const jk=`${today}_temp_join_${tc.studentName}_${tc.time}`;

      if(waReady && inWindow(cur,tc.time,sb,5) && !sentToday.has(sk)){
        if(!tc.whatsappNumber) {
          addLog('warn',`[Temp] WhatsApp Number নেই: ${tc.studentName} — skip`);
          sentToday.add(sk);
          saveSentToday();
        } else {
          const phone1 = String(tc.whatsappNumber).replace(/\D/g,'');
          if(!phone1) {
            addLog('warn',`[Temp] অবৈধ Number: ${tc.studentName} — skip`);
            sentToday.add(sk);
            saveSentToday();
          } else {
            const alreadySent = await isLinkAlreadySentInChat(phone1, tc.meetLink, tc.time);
            if(alreadySent) {
              addLog('info', `[Temporary] Link already sent manually to ${tc.studentName} (+${phone1}) for class at ${tc.time}, skipping auto-send.`);
              sentToday.add(sk);
              saveSentToday();
            } else {
              sentToday.add(sk);
              saveSentToday();
              await sendWA(cls,`[টেম্পোরারি] ${settings.joinMeetMessage}\n${tc.meetLink}`);
            }
          }
        }
      }

      if(inWindow(cur,tc.time,jb,5) && !joinedToday.has(jk)){
        joinedToday.add(jk);
        saveSentToday();
        joinMeet(cls).catch(()=>{});
      }
    }

    // ── ৩. কাউন্সেলিং সেশন ──
    for(const cs of counselingSessions){
      if(cs.enabled===false||cs.date!==today) continue;
      const cls={studentName:cs.name,whatsappNumber:cs.whatsappNumber,whatsappNumber2:cs.whatsappNumber2||null,meetLink:cs.meetLink,time:cs.time};
      const sk=`${today}_counsel_msg_${cs.name}_${cs.time}`;
      const jk=`${today}_counsel_join_${cs.name}_${cs.time}`;

      if(waReady && inWindow(cur,cs.time,sb,5) && !sentToday.has(sk)){
        if(!cs.whatsappNumber) {
          addLog('warn',`[Counseling] WhatsApp Number নেই: ${cs.name} — skip`);
          sentToday.add(sk);
          saveSentToday();
        } else {
          const phone1 = String(cs.whatsappNumber).replace(/\D/g,'');
          if(!phone1) {
            addLog('warn',`[Counseling] অবৈধ Number: ${cs.name} — skip`);
            sentToday.add(sk);
            saveSentToday();
          } else {
            const alreadySent = await isLinkAlreadySentInChat(phone1, cs.meetLink, cs.time);
            if(alreadySent) {
              addLog('info', `[Counseling] Link already sent manually to ${cs.name} (+${phone1}) for class at ${cs.time}, skipping auto-send.`);
              sentToday.add(sk);
              saveSentToday();
            } else {
              sentToday.add(sk);
              saveSentToday();
              await sendWA(cls,`${settings.counselingMessage}\n${cs.meetLink}`);
            }
          }
        }
      }

      if(inWindow(cur,cs.time,jb,5) && !joinedToday.has(jk)){
        joinedToday.add(jk);
        saveSentToday();
        joinMeet(cls).catch(()=>{});
      }
    }
  } finally {
    isCheckingSchedule = false;
  }
}
// ✅ দৈনিক reset বাদ দেওয়া হয়েছে — sentToday/joinedToday তে date-prefix আছে, তাই Reset ছাড়াই কাজ করবে।

// ── Server Start ───────────────────────────────────────────────
// ✅ Port conflict detection — আগে থেকে Port 3000 দখল থাকলে বাংলায় error দেখাবে
server.on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error('\n');
    console.error('  ❌ ত্রুটি: Port 3000 ইতিমধ্যে ব্যবহৃত হচ্ছে!');
    console.error('  📋 সমাধান: অন্য কোনো GIC বট বা প্রোগ্রাম Port 3000 দখল করে আছে।');
    console.error('  👉 Task Manager খুলুন → node.exe বন্ধ করুন → আবার চেষ্টা করুন।');
    console.error('  ⚠️  অথবা: "GIC Master Control" এবং "GIC App" একসাথে চালাবেন না।\n');
    process.exit(1);
  } else {
    console.error('Server error:', err.message);
    process.exit(1);
  }
});

server.listen(3000,'localhost',() => {
  console.clear();
  console.log('\n');
  console.log('  ╔══════════════════════════════════════════════════════╗');
  console.log('  ║     🕌  GIC — Global Islamic Care চালু হয়েছে!       ║');
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log('  ║  🌐  Dashboard  →  http://localhost:3000             ║');
  console.log('  ╠══════════════════════════════════════════════════════╣');
  console.log('  ║  📱  একটাই WhatsApp সংযোগ — সব কাজ এখান থেকে      ║');
  console.log('  ║  📲  QR Code নিচে দেখাবে — একবার স্ক্যান করুন      ║');
  console.log('  ║  ✅  পরেরবার আর লাগবে না — session সেভ থাকবে       ║');
  console.log('  ║  ⛔  বন্ধ করতে Ctrl+C চাপুন                        ║');
  console.log('  ╚══════════════════════════════════════════════════════╝\n');

  addLog('info','GIC চালু — WhatsApp সংযোগ হচ্ছে...');
  // ✅ .catch() যোগ — unhandled rejection থেকে process crash বন্ধ
  waClient.initialize().catch(e => {
    addLog('error', 'WhatsApp initialize ব্যর্থ: ' + e.message);
    scheduleReconnect(10000);
  });
  // ✅ Bug fix #6: প্রথমে একবার check করো, তারপর interval শুরু করো
  // (WhatsApp ready হওয়ার আগে checkSchedule নিজেই return করে — নিরাপদ)
  setTimeout(checkSchedule, 5000);
  setInterval(checkSchedule, CHECK_INTERVAL_MS);
  setTimeout(() => exec('start http://localhost:3000'), 3000);

  // ✅ WhatsApp Heartbeat — প্রতি ৫ মিনিটে session health check করে
  setInterval(async () => {
    if (!waReady || waReconnecting || waShuttingDown) return;
    try {
      // getState() — WhatsApp session alive আছে কিনা প্রমাণ করে
      const state = await waClient.getState();
      if (state !== 'CONNECTED') {
        addLog('warn', `⚠️ WhatsApp heartbeat: state = ${state} — reconnect করছি...`);
        waReady = false;
        scheduleReconnect(3000);
      }
      // state === 'CONNECTED' → সব ভালো আছে, কিছু করার নেই
    } catch(e) {
      // ✅ Store timing error = session alive, reconnect করবো না
      if (isStoreError(e.message)) {
        addLog('warn', `WhatsApp heartbeat: store timing error (non-critical, session alive): ${e.message.slice(0, 80)}`);
        return; // reconnect করবো না
      }
      if (isWAContextError(e.message)) {
        addLog('warn', `⚠️ WhatsApp heartbeat context error — reconnect করছি: ${e.message}`);
        waReady = false;
        if (!waReconnecting) scheduleReconnect(5000);
      } else {
        addLog('warn', `WhatsApp heartbeat error (non-critical): ${e.message}`);
      }
    }
  }, 5 * 60 * 1000); // প্রতি ৫ মিনিটে
});


// ✅ Global error handlers — যেকোনো কারণে process crash হবে না
// (isWAContextError helper উপরে line ~145 এ define করা আছে)

process.on('unhandledRejection', (reason) => {
  const msg = (reason instanceof Error ? reason.message : String(reason)) || 'Unknown';

  // ✅ Store timing error — transient, safeSendMessage retry-তে handle হয়
  // এখানে reconnect করা ঠিক না — user workflow break হয়
  if (isStoreError(msg)) {
    addLog('warn', `WhatsApp store timing error (transient — retry হচ্ছে): ${msg}`);
    return; // reconnect করবে না
  }

  addLog('error', 'Unhandled rejection: ' + msg);
  // WhatsApp session/frame সম্পূর্ণ broken → reconnect দরকার
  if (isWAContextError(msg)) {
    addLog('warn', 'WhatsApp context হারিয়ে গেছে — reconnect হবে...');
    waReady = false;
    if (!waReconnecting) scheduleReconnect(10000);
  }
});


process.on('uncaughtException', (err) => {
  addLog('error', 'Uncaught exception: ' + err.message);
  // ECONNRESET বা অনুরূপ network error হলে process বন্ধ করবে না
  if (
    err.message.includes('ECONNRESET') ||
    err.message.includes('ECONNREFUSED') ||
    isWAContextError(err.message)           // ✅ FIX: shared helper ব্যবহার করা হচ্ছে
  ) {
    addLog('warn', 'পুনরুদ্ধারযোগ্য error — bot চলতে থাকবে');
    // ✅ FIX: WhatsApp context error হলে reconnect
    if (isWAContextError(err.message)) {
      waReady = false;
      if (!waReconnecting) scheduleReconnect(10000);
    }
    return; // process চালু রাখো
  }
  // অন্য critical error হলে graceful exit
  console.error('[GIC] Critical error — বন্ধ হচ্ছে:', err.message);
  try { waClient.destroy(); } catch(_) {}
  process.exit(1);
});

process.on('SIGINT', () => {
  console.log('\n  GIC বন্ধ হচ্ছে...');
  waShuttingDown = true; // ✅ Bug fix: reconnect loop বন্ধ করো
  waReconnecting = true; // block any pending reconnect
  try{ waClient.destroy(); }catch(_){}
  process.exit(0);
});

// ═══════════════════════════════════════════════════════════════
//  DASHBOARD HTML (embedded)
// ═══════════════════════════════════════════════════════════════
const DASHBOARD = `<!DOCTYPE html>
<html lang="en">
<head>
<script>function hcov(id){var el=document.getElementById(id);if(el)el.classList.add("h");}window.hcov=hcov;</script>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GIC — Global Islamic Care</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Outfit:wght@600;700;800;900&family=Hind+Siliguri:wght@400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#070c18;--bg2:#0c1322;--bg3:#101929;
  --surface:rgba(255,255,255,.04);--surface2:rgba(255,255,255,.07);
  --border:rgba(255,255,255,.08);--border2:rgba(255,255,255,.13);
  --gold:#f5c518;--gold2:#d97706;--gold-glow:rgba(245,197,24,.2);
  --green:#10b981;--green-glow:rgba(16,185,129,.2);
  --red:#f43f5e;--amber:#f59e0b;--blue:#3b82f6;--purple:#8b5cf6;
  --t:#e8eef8;--t2:#8da0bc;--t3:#4a6080;
  --nav-h:54px;
}
html,body{height:100%;overflow:hidden;font-family:'Inter','Hind Siliguri',sans-serif;background:var(--bg);color:var(--t)}
body{display:flex;flex-direction:column;position:relative}

/* ── Animated Background ── */
body::before{
  content:'';position:fixed;inset:0;pointer-events:none;z-index:0;
  background:
    radial-gradient(ellipse 70% 55% at 15% 5%, rgba(59,130,246,.09) 0%, transparent 65%),
    radial-gradient(ellipse 50% 45% at 85% 90%, rgba(139,92,246,.08) 0%, transparent 65%),
    radial-gradient(ellipse 35% 35% at 50% 50%, rgba(245,197,24,.04) 0%, transparent 60%);
}

/* ── Navigation ── */
.nav{
  height:var(--nav-h);flex-shrink:0;position:relative;z-index:100;
  background:rgba(7,12,24,.92);backdrop-filter:blur(20px);
  border-bottom:1px solid rgba(245,197,24,.1);
  display:flex;align-items:center;padding:0 8px;gap:2px;overflow-x:auto;
  box-shadow:0 1px 0 rgba(255,255,255,.04), 0 4px 24px rgba(0,0,0,.5);
}
.nav::-webkit-scrollbar{height:0}

.brand{
  display:flex;align-items:center;gap:9px;
  padding:0 10px 0 4px;margin-right:4px;
  border-right:1px solid var(--border);flex-shrink:0;
}
.brand-icon{
  width:30px;height:30px;border-radius:8px;
  background:linear-gradient(135deg,var(--gold),var(--gold2));
  display:flex;align-items:center;justify-content:center;font-size:15px;
  box-shadow:0 0 16px var(--gold-glow);flex-shrink:0;
}
.brand-name{font-size:12px;font-weight:800;font-family:'Outfit',sans-serif;letter-spacing:.2px}
.brand-sub{font-size:9px;color:var(--t3);margin-top:1px;letter-spacing:.5px}

/* Tab buttons */
.tab{
  display:flex;align-items:center;gap:5px;
  padding:5px 11px;border-radius:8px;
  border:1px solid transparent;cursor:pointer;
  font-size:11px;font-weight:600;color:var(--t3);
  white-space:nowrap;transition:all .16s cubic-bezier(.4,0,.2,1);
  flex-shrink:0;background:transparent;font-family:inherit;
}
.tab-ico{font-size:12px;transition:transform .2s}
.tab:hover{background:var(--surface2);color:var(--t2);border-color:var(--border)}
.tab:hover .tab-ico{transform:scale(1.18)}
.tab.on{
  background:linear-gradient(135deg,rgba(245,197,24,.12),rgba(245,197,24,.05));
  border-color:rgba(245,197,24,.22);color:var(--gold);
  box-shadow:0 0 12px rgba(245,197,24,.07),inset 0 1px 0 rgba(245,197,24,.08);
}
.tab.on .tab-ico{transform:scale(1.1)}
.tab-v.on{
  background:linear-gradient(135deg,rgba(139,92,246,.12),rgba(139,92,246,.05));
  border-color:rgba(139,92,246,.28);color:#a78bfa;
  box-shadow:0 0 12px rgba(139,92,246,.08);
}
.tab-v:hover{color:#c4b5fd}
.nav-div{width:1px;height:22px;background:var(--border);flex-shrink:0;margin:0 2px}

/* Status area */
.nav-right{margin-left:auto;display:flex;align-items:center;gap:8px;flex-shrink:0;padding-left:8px}
.wdot{width:8px;height:8px;border-radius:50%;flex-shrink:0;transition:all .3s}
.wdot.g{background:var(--green);box-shadow:0 0 8px var(--green);animation:pulse-g 2s infinite}
.wdot.y{background:var(--amber);animation:blink .8s infinite}
.wdot.r{background:var(--red)}
.wdot.x{background:var(--t3)}
.wst{font-size:10.5px;font-weight:700;color:var(--t2)}
.clk{font-size:11.5px;font-weight:800;color:var(--gold);font-variant-numeric:tabular-nums;letter-spacing:.6px;font-family:'Outfit',sans-serif}
@keyframes pulse-g{0%,100%{opacity:1;box-shadow:0 0 8px var(--green)}50%{opacity:.5;box-shadow:0 0 4px var(--green)}}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.15}}

/* ── Panels ── */
.cnt{flex:1;position:relative;overflow:hidden;z-index:1}
.pnl{position:absolute;inset:0;opacity:0;pointer-events:none;transition:opacity .2s;z-index:1}
.pnl.on{opacity:1;pointer-events:auto;z-index:2}
.pnl iframe{width:100%;height:100%;border:none;display:block}
.scroll-panel{height:100%;overflow-y:auto}
.scroll-panel::-webkit-scrollbar{width:4px}
.scroll-panel::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:4px}
.hw{max-width:820px;margin:0 auto;padding:20px 16px 60px;width:100%}

/* ── Cards ── */
.card{
  background:var(--bg2);
  border:1px solid var(--border);
  border-radius:14px;padding:18px 20px;
  transition:border-color .2s;
  position:relative;overflow:hidden;
}
.card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:1px;
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.07),transparent);
}

/* ── Home Page 2-Col Layout ── */
.home-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px}
.home-grid-full{grid-column:1/-1}

/* Hero banner */
.hero{
  grid-column:1/-1;
  background:linear-gradient(120deg,rgba(245,197,24,.08) 0%,rgba(59,130,246,.05) 50%,rgba(139,92,246,.04) 100%);
  border:1px solid rgba(245,197,24,.12);border-radius:16px;
  padding:20px 24px;position:relative;overflow:hidden;
}
.hero::after{content:'🕌';position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:54px;opacity:.06;pointer-events:none}
.hero h1{font-size:18px;font-weight:900;font-family:'Outfit',sans-serif;letter-spacing:-.3px;margin-bottom:4px}
.hero em{color:var(--gold);font-style:normal}
.hero p{font-size:11.5px;color:var(--t2);line-height:1.7;max-width:420px}

/* WhatsApp status card */
.wa-card{
  background:linear-gradient(135deg,rgba(16,185,129,.07),rgba(16,185,129,.02));
  border:1px solid rgba(16,185,129,.15);border-radius:14px;
  padding:16px 18px;
}
.wa-head{display:flex;align-items:center;gap:12px;margin-bottom:12px}
.wa-icon{
  width:40px;height:40px;border-radius:10px;flex-shrink:0;
  background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.18);
  display:flex;align-items:center;justify-content:center;font-size:20px;
}
.wa-title{font-size:13px;font-weight:800;margin-bottom:2px}
.wa-sub{font-size:10.5px;color:var(--t2)}
.wa-badge{display:inline-flex;align-items:center;gap:6px;padding:4px 11px;border-radius:20px;font-size:10.5px;font-weight:700;border:1px solid}
.wa-r{color:var(--green);border-color:rgba(16,185,129,.28);background:rgba(16,185,129,.08)}
.wa-y{color:var(--amber);border-color:rgba(245,158,11,.28);background:rgba(245,158,11,.08)}
.wa-x{color:var(--t3);border-color:var(--border);background:var(--surface)}
#qr-area{
  background:var(--surface);border:1px solid rgba(245,197,24,.12);
  border-radius:11px;padding:16px;text-align:center;margin-top:12px;display:none;
}
#qr-area p{font-size:11px;color:var(--t2);margin-bottom:10px;line-height:1.65}
#qr-img{max-width:180px;border-radius:9px;border:2px solid var(--gold)}

/* Tool grid */
.tools-grid{display:grid;grid-template-columns:1fr 1fr;gap:9px}
.tool-btn{
  display:flex;align-items:center;gap:10px;
  background:var(--surface);border:1px solid var(--border);
  border-radius:11px;padding:13px 14px;cursor:pointer;
  transition:all .18s cubic-bezier(.4,0,.2,1);
  text-align:left;font-family:inherit;color:var(--t);
}
.tool-btn:hover{background:var(--surface2);border-color:var(--border2);transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.3)}
.tool-icon{font-size:20px;flex-shrink:0;width:32px;text-align:center}
.tool-name{font-size:12px;font-weight:700;line-height:1;margin-bottom:3px}
.tool-desc{font-size:10px;color:var(--t3)}
.tool-btn.purple{border-color:rgba(139,92,246,.18);background:rgba(139,92,246,.05)}
.tool-btn.purple:hover{background:rgba(139,92,246,.1);border-color:rgba(139,92,246,.28)}

/* Log box */
.log-box{
  background:rgba(0,0,0,.25);border:1px solid var(--border);
  border-radius:11px;padding:10px 12px;font-family:'JetBrains Mono',monospace;font-size:10.5px;
  height:190px;overflow-y:auto;
}
.log-box::-webkit-scrollbar{width:3px}
.log-box::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:3px}
.le{padding:2.5px 0;border-bottom:1px solid rgba(255,255,255,.03);display:flex;gap:8px;align-items:baseline}
.lt{color:var(--t3);flex-shrink:0;font-size:9.5px;min-width:48px}
.li{color:var(--t)}.ls{color:var(--green)}.lr{color:var(--red)}.lw{color:var(--amber)}

/* Section heading */
.sec{
  font-size:9.5px;font-weight:700;letter-spacing:2px;text-transform:uppercase;
  color:var(--t3);margin:18px 0 10px;
  display:flex;align-items:center;gap:8px;
}
.sec::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,var(--border),transparent)}

/* Tip banner */
.tip{
  background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.18);
  border-radius:10px;padding:11px 14px;font-size:11px;color:var(--amber);
  line-height:1.65;display:flex;gap:9px;align-items:flex-start;margin-top:14px;
}

/* Loading overlay */
.cov{position:absolute;inset:0;background:var(--bg2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:var(--t2);font-size:11px;transition:opacity .3s;z-index:5}
.cov.h{opacity:0;pointer-events:none}
.sp{width:24px;height:24px;border-radius:50%;border:2.5px solid var(--border);border-top-color:var(--gold);animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* Toast */
#ts{position:fixed;bottom:14px;right:14px;z-index:999;display:flex;flex-direction:column;gap:5px}
.tt{
  background:rgba(12,19,34,.95);backdrop-filter:blur(12px);
  border:1px solid var(--border2);border-radius:9px;
  padding:9px 14px;font-size:11px;
  box-shadow:0 6px 24px rgba(0,0,0,.6);
  animation:tin .28s cubic-bezier(.34,1.56,.64,1) forwards;
}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}

/* ══════════════════════════════
   STUDENTS PANEL
══════════════════════════════ */
.stu-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap}
.stu-search{
  flex:1;min-width:160px;display:flex;align-items:center;gap:8px;
  background:var(--surface);border:1px solid var(--border);border-radius:10px;
  padding:8px 12px;transition:border-color .18s;
}
.stu-search:focus-within{border-color:rgba(245,197,24,.3)}
.stu-search input{flex:1;background:transparent;border:none;outline:none;color:var(--t);font-size:12.5px;font-family:inherit}
.stu-search input::placeholder{color:var(--t3)}
.stu-count{
  display:inline-flex;align-items:center;justify-content:center;
  min-width:22px;height:22px;padding:0 7px;border-radius:11px;
  background:rgba(245,197,24,.12);color:var(--gold);font-size:11px;font-weight:700;
}
.btn-add{
  padding:8px 16px;border-radius:9px;
  background:linear-gradient(135deg,var(--green),#059669);
  color:#fff;border:none;font-size:11.5px;font-weight:700;
  cursor:pointer;font-family:inherit;transition:all .18s;
  box-shadow:0 4px 14px var(--green-glow);white-space:nowrap;
}
.btn-add:hover{transform:translateY(-1px);box-shadow:0 6px 20px var(--green-glow)}

/* Student cards */
.stu-card{
  background:var(--bg2);border:1px solid var(--border);border-radius:12px;
  padding:12px 14px;display:flex;align-items:center;gap:12px;
  transition:all .16s;
}
.stu-card:hover{border-color:var(--border2);background:rgba(255,255,255,.03);transform:translateX(2px)}
.stu-avatar{
  width:38px;height:38px;border-radius:10px;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  font-size:14px;font-weight:800;font-family:'Outfit',sans-serif;
  letter-spacing:-.5px;
}
.av-hifz{background:rgba(245,197,24,.15);color:var(--gold)}
.av-nazera{background:rgba(16,185,129,.15);color:var(--green)}
.av-tajweed{background:rgba(59,130,246,.15);color:var(--blue)}
.av-other{background:rgba(139,92,246,.15);color:var(--purple)}
.stu-name{font-size:13px;font-weight:700;color:var(--t);margin-bottom:4px}
.stu-tags{display:flex;flex-wrap:wrap;gap:4px}
.stu-tag{
  display:inline-flex;align-items:center;gap:3px;
  background:var(--surface);border:1px solid var(--border);
  border-radius:5px;padding:2px 7px;font-size:10px;color:var(--t2);
}
.cat-chip{font-weight:700;font-size:9.5px;letter-spacing:.8px;text-transform:uppercase;padding:2px 7px;border-radius:5px}
.chip-hifz{background:rgba(245,197,24,.12);color:var(--gold);border:1px solid rgba(245,197,24,.2)}
.chip-nazera{background:rgba(16,185,129,.1);color:var(--green);border:1px solid rgba(16,185,129,.2)}
.chip-tajweed{background:rgba(59,130,246,.1);color:var(--blue);border:1px solid rgba(59,130,246,.2)}
.chip-other{background:rgba(139,92,246,.1);color:var(--purple);border:1px solid rgba(139,92,246,.2)}
.btn-edit{
  padding:5px 11px;border-radius:7px;border:1px solid var(--border);
  background:var(--surface);color:var(--t2);font-size:10.5px;
  cursor:pointer;font-family:inherit;transition:all .15s;font-weight:600;
}
.btn-edit:hover{background:var(--surface2);color:var(--t)}
.btn-del{
  padding:5px 9px;border-radius:7px;border:1px solid rgba(244,63,94,.2);
  background:rgba(244,63,94,.06);color:var(--red);font-size:10.5px;
  cursor:pointer;font-family:inherit;transition:all .15s;
}
.btn-del:hover{background:rgba(244,63,94,.13)}

/* Modal */
.modal-bg{display:none;position:absolute;inset:0;background:rgba(0,0,0,.7);z-index:100;align-items:center;justify-content:center;backdrop-filter:blur(6px)}
.modal-box{
  background:var(--bg3);border:1px solid var(--border2);
  border-radius:18px;padding:26px;width:90%;max-width:440px;
  max-height:90vh;overflow-y:auto;
  box-shadow:0 30px 70px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.04);
}
.modal-box::-webkit-scrollbar{width:4px}
.modal-box::-webkit-scrollbar-thumb{background:var(--border);border-radius:4px}
.modal-title{font-size:14px;font-weight:800;font-family:'Outfit',sans-serif;color:var(--gold);margin-bottom:18px;padding-bottom:14px;border-bottom:1px solid var(--border)}
.field-group{display:flex;flex-direction:column;gap:11px}
.field label{font-size:10.5px;color:var(--t2);display:block;margin-bottom:5px;font-weight:700;text-transform:uppercase;letter-spacing:.8px}
.field input,.field select{
  width:100%;padding:9px 12px;border-radius:9px;
  border:1px solid var(--border);background:rgba(255,255,255,.04);
  color:var(--t);font-size:13px;font-family:inherit;
  transition:border-color .18s;outline:none;
}
.field input:focus,.field select:focus{border-color:rgba(245,197,24,.35);background:rgba(245,197,24,.03)}
.field select option{background:#101929}
.modal-actions{display:flex;gap:9px;margin-top:20px}
.btn-cancel{
  flex:1;padding:10px;border-radius:9px;
  border:1px solid var(--border);background:var(--surface);
  color:var(--t2);font-size:13px;font-weight:700;
  cursor:pointer;font-family:inherit;transition:all .15s;
}
.btn-cancel:hover{background:var(--surface2)}
.btn-save{
  flex:2;padding:10px;border-radius:9px;
  background:linear-gradient(135deg,var(--green),#059669);
  color:#fff;border:none;font-size:13px;font-weight:700;
  cursor:pointer;font-family:inherit;transition:all .18s;
  box-shadow:0 4px 14px var(--green-glow);
}
.btn-save:hover{transform:translateY(-1px)}

/* ══════════════════════════════
   EXTRA MESSAGE PANEL
══════════════════════════════ */
.em-hero{
  background:linear-gradient(120deg,rgba(139,92,246,.1),rgba(59,130,246,.05));
  border:1px solid rgba(139,92,246,.2);border-radius:16px;
  padding:18px 22px;margin-bottom:16px;position:relative;overflow:hidden;
}
.em-hero::after{content:'💬';position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:48px;opacity:.07;pointer-events:none}
.em-hero h1{font-size:17px;font-weight:900;font-family:'Outfit',sans-serif;margin-bottom:3px}
.em-hero em{color:#a78bfa;font-style:normal}
.em-hero p{font-size:11px;color:var(--t2);line-height:1.7;max-width:400px}
.wa-alert{
  background:rgba(245,158,11,.07);border:1px solid rgba(245,158,11,.2);
  border-radius:10px;padding:11px 14px;font-size:11px;color:var(--amber);
  display:flex;gap:9px;margin-bottom:14px;align-items:center;
}
.em-card{background:var(--bg2);border:1px solid var(--border);border-radius:14px;padding:18px 20px;margin-bottom:14px}
.em-card-title{font-size:12px;font-weight:800;color:var(--t);margin-bottom:13px;display:flex;align-items:center;gap:7px}
.em-textarea{
  width:100%;min-height:120px;padding:12px 14px;
  border-radius:10px;border:1px solid var(--border);
  background:rgba(0,0,0,.2);color:var(--t);
  font-size:13px;font-family:'Inter','Hind Siliguri',sans-serif;
  line-height:1.7;resize:vertical;outline:none;transition:border-color .18s;
}
.em-textarea:focus{border-color:rgba(139,92,246,.4);background:rgba(139,92,246,.03)}
.em-textarea::placeholder{color:var(--t3)}
.em-char{font-size:10px;color:var(--t3);text-align:right;margin-top:5px}

.em-all-btn{
  display:flex;align-items:center;gap:9px;padding:10px 13px;
  border-radius:9px;border:1px solid var(--border);background:var(--surface);
  cursor:pointer;font-size:12px;font-weight:600;color:var(--t);font-family:inherit;
  width:100%;margin-bottom:8px;transition:all .18s;
}
.em-all-btn:hover{background:rgba(139,92,246,.08);border-color:rgba(139,92,246,.22)}
.em-all-btn.sel{background:rgba(139,92,246,.1);border-color:rgba(139,92,246,.32);color:#c4b5fd}
.em-checkbox-row{display:flex;flex-direction:column;gap:6px;max-height:210px;overflow-y:auto;padding-right:2px}
.em-checkbox-row::-webkit-scrollbar{width:3px}
.em-checkbox-row::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
.em-stu-cb{
  display:flex;align-items:center;gap:9px;padding:8px 12px;
  border-radius:9px;border:1px solid var(--border);background:var(--surface);
  cursor:pointer;transition:all .15s;
}
.em-stu-cb:hover{background:var(--surface2);border-color:var(--border2)}
.em-stu-cb.sel{background:rgba(139,92,246,.08);border-color:rgba(139,92,246,.22)}
.em-stu-cb input[type=checkbox]{accent-color:#8b5cf6;width:14px;height:14px;cursor:pointer;flex-shrink:0}
.em-stu-cb-name{font-size:12px;font-weight:700;color:var(--t);line-height:1}
.em-stu-cb-phone{font-size:10px;color:var(--t2);margin-top:2px}

.btn-send{
  width:100%;padding:13px;border-radius:11px;
  background:linear-gradient(135deg,#8b5cf6,#7c3aed);
  color:#fff;border:none;font-size:13px;font-weight:800;font-family:'Outfit',sans-serif;
  cursor:pointer;transition:all .2s;letter-spacing:.3px;
  box-shadow:0 6px 20px rgba(139,92,246,.28);
  display:flex;align-items:center;justify-content:center;gap:8px;
}
.btn-send:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 10px 30px rgba(139,92,246,.38)}
.btn-send:disabled{opacity:.45;cursor:not-allowed;transform:none}
.em-result{border-radius:11px;padding:14px;margin-top:13px;display:none}
.em-result.ok{background:rgba(16,185,129,.07);border:1px solid rgba(16,185,129,.18)}
.em-result.err{background:rgba(244,63,94,.07);border:1px solid rgba(244,63,94,.18)}
.em-result-title{font-size:12px;font-weight:800;margin-bottom:8px}
.em-result-row{font-size:11px;padding:3px 0;display:flex;align-items:center;gap:7px;color:var(--t2)}

/* ══════════════════════════════
   TEACHERS TAB STYLING
══════════════════════════════ */
.tab-teacher.on{
  background:linear-gradient(135deg,rgba(245,158,11,.12),rgba(245,158,11,.05));
  border-color:rgba(245,158,11,.28);color:#fbbf24;
  box-shadow:0 0 12px rgba(245,158,11,.08);
}
.tab-teacher:hover{color:#fde68a}

/* Teacher hero */
.teacher-hero{
  background:linear-gradient(120deg,rgba(245,158,11,.09),rgba(16,185,129,.05));
  border:1px solid rgba(245,158,11,.16);border-radius:16px;
  padding:20px 24px;margin-bottom:16px;position:relative;overflow:hidden;
}
.teacher-hero::after{content:'\ud83d\udc68\u200d\ud83c\udfeb';position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:52px;opacity:.07;pointer-events:none}
.teacher-hero h1{font-size:18px;font-weight:900;font-family:'Outfit',sans-serif;margin-bottom:4px}
.teacher-hero em{color:#fbbf24;font-style:normal}
.teacher-hero p{font-size:11.5px;color:var(--t2);line-height:1.7}

/* Teacher toolbar */
.teacher-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:16px;flex-wrap:wrap}
.btn-add-teacher{
  padding:8px 16px;border-radius:9px;
  background:linear-gradient(135deg,#f59e0b,#d97706);
  color:#000;border:none;font-size:11.5px;font-weight:800;
  cursor:pointer;font-family:inherit;transition:all .18s;
  box-shadow:0 4px 14px rgba(245,158,11,.3);white-space:nowrap;
}
.btn-add-teacher:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(245,158,11,.4)}

/* Teacher cards */
.teacher-card{
  background:var(--bg2);border:1px solid var(--border);border-radius:12px;
  padding:14px 16px;display:flex;align-items:center;gap:13px;
  transition:all .16s;position:relative;overflow:hidden;
}
.teacher-card::before{
  content:'';position:absolute;left:0;top:0;bottom:0;width:0;
  background:linear-gradient(180deg,#f59e0b,#d97706);
  transition:width .2s;border-radius:12px 0 0 12px;
}
.teacher-card:hover::before{width:3px}
.teacher-card:hover{border-color:rgba(245,158,11,.2);background:rgba(245,158,11,.03);transform:translateX(2px)}
.teacher-avatar{
  width:42px;height:42px;border-radius:12px;flex-shrink:0;
  background:linear-gradient(135deg,rgba(245,158,11,.18),rgba(245,158,11,.06));
  border:1px solid rgba(245,158,11,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:15px;font-weight:800;font-family:'Outfit',sans-serif;
  color:#f59e0b;letter-spacing:-.5px;
}
.teacher-name{font-size:13px;font-weight:800;color:var(--t);margin-bottom:4px}
.teacher-tags{display:flex;flex-wrap:wrap;gap:4px;align-items:center}
.teacher-tag{
  display:inline-flex;align-items:center;gap:3px;
  background:var(--surface);border:1px solid var(--border);
  border-radius:5px;padding:2px 8px;font-size:10px;color:var(--t2);
}
.teacher-count-badge{
  background:rgba(245,158,11,.12);border:1px solid rgba(245,158,11,.2);
  color:#fbbf24;border-radius:5px;padding:2px 8px;font-size:10px;font-weight:700;
}
.teacher-login-link{
  font-size:10px;color:var(--t3);background:var(--surface);
  border:1px solid var(--border);border-radius:5px;padding:2px 8px;
  cursor:pointer;transition:all .15s;
}
.teacher-login-link:hover{color:var(--gold);border-color:rgba(245,197,24,.25)}

/* Teacher-specific modal */
#teacher-modal .modal-title{color:#fbbf24}
#teacher-modal .btn-save{background:linear-gradient(135deg,#f59e0b,#d97706);box-shadow:0 4px 14px rgba(245,158,11,.3)}
#teacher-modal .btn-save:hover{transform:translateY(-1px)}

/* Student assign checkboxes in teacher modal */
.assign-list{display:flex;flex-direction:column;gap:5px;max-height:200px;overflow-y:auto;padding-right:2px;margin-top:8px}
.assign-list::-webkit-scrollbar{width:3px}
.assign-list::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
.assign-row{
  display:flex;align-items:center;gap:9px;padding:7px 11px;
  border-radius:8px;border:1px solid var(--border);background:var(--surface);
  cursor:pointer;transition:all .15s;
}
.assign-row:hover{background:var(--surface2)}
.assign-row.sel{background:rgba(245,158,11,.07);border-color:rgba(245,158,11,.22)}
.assign-row input[type=checkbox]{accent-color:#f59e0b;width:14px;height:14px;cursor:pointer;flex-shrink:0}
.assign-name{font-size:12px;font-weight:700;color:var(--t)}
.assign-phone{font-size:10px;color:var(--t2)}

/* Teacher link info box */
.teacher-link-box{
  background:rgba(245,158,11,.06);border:1px solid rgba(245,158,11,.18);
  border-radius:10px;padding:12px 15px;font-size:11.5px;
  display:flex;gap:9px;align-items:flex-start;margin-bottom:14px;
}
.teacher-link-url{
  font-size:11px;font-weight:700;color:#fbbf24;
  background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.2);
  border-radius:6px;padding:5px 10px;margin-top:6px;display:inline-block;
  cursor:pointer;letter-spacing:.3px;
}
.teacher-link-url:hover{background:rgba(245,158,11,.18)}

/* ══════════════════════════════
   PAYMENT TAB STYLING
══════════════════════════════ */
.tab-pay.on{
  background:linear-gradient(135deg,rgba(16,185,129,.12),rgba(16,185,129,.05));
  border-color:rgba(16,185,129,.28);color:#34d399;
  box-shadow:0 0 12px rgba(16,185,129,.08);
}
.tab-pay:hover{color:#6ee7b7}

.payment-hero{
  background:linear-gradient(120deg,rgba(16,185,129,.09),rgba(59,130,246,.04));
  border:1px solid rgba(16,185,129,.16);border-radius:16px;
  padding:20px 24px;margin-bottom:14px;position:relative;overflow:hidden;
}
.payment-hero::after{content:'\ud83d\udcb0';position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:52px;opacity:.07;pointer-events:none}
.payment-hero h1{font-size:18px;font-weight:900;font-family:'Outfit',sans-serif;margin-bottom:4px}
.payment-hero em{color:#34d399;font-style:normal}
.payment-hero p{font-size:11.5px;color:var(--t2);line-height:1.7}

.pay-summary{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px;margin-bottom:16px}
.pay-stat{background:var(--bg2);border:1px solid var(--border);border-radius:12px;padding:14px 16px;text-align:center}
.pay-stat-val{font-size:22px;font-weight:900;font-family:'Outfit',sans-serif;line-height:1;margin-bottom:4px}
.pay-stat-lbl{font-size:9.5px;text-transform:uppercase;letter-spacing:.8px;color:var(--t3);font-weight:700}
.pay-stat.income .pay-stat-val{color:#34d399}
.pay-stat.paid .pay-stat-val{color:#60a5fa}
.pay-stat.pending .pay-stat-val{color:#f59e0b}
.pay-stat.expected .pay-stat-val{color:var(--t2)}

.pay-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:14px;flex-wrap:wrap}
.month-picker{
  padding:7px 12px;border-radius:9px;border:1px solid var(--border);
  background:var(--bg2);color:var(--t);font-size:12px;font-family:inherit;
  outline:none;cursor:pointer;
}
.month-picker:focus{border-color:rgba(16,185,129,.35)}
.btn-add-pay{
  padding:8px 16px;border-radius:9px;
  background:linear-gradient(135deg,#10b981,#059669);
  color:#fff;border:none;font-size:11.5px;font-weight:800;
  cursor:pointer;font-family:inherit;transition:all .18s;
  box-shadow:0 4px 14px rgba(16,185,129,.3);white-space:nowrap;
}
.btn-add-pay:hover{transform:translateY(-1px);box-shadow:0 6px 20px rgba(16,185,129,.4)}

.pay-table{width:100%;border-collapse:collapse;font-size:12px}
.pay-table th{background:rgba(255,255,255,.04);padding:8px 10px;text-align:left;color:var(--t2);font-size:10px;text-transform:uppercase;letter-spacing:.8px;font-weight:700;border-bottom:1px solid var(--border)}
.pay-table td{padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
.pay-table tr:hover td{background:rgba(255,255,255,.02)}
.pay-badge{display:inline-block;padding:2px 8px;border-radius:6px;font-size:10px;font-weight:700}
.pay-badge.paid{background:rgba(16,185,129,.12);color:#34d399;border:1px solid rgba(16,185,129,.2)}
.pay-badge.pending{background:rgba(245,158,11,.12);color:#fbbf24;border:1px solid rgba(245,158,11,.2)}
.pay-amount{font-weight:800;font-size:13px;color:#34d399;font-family:'Outfit',sans-serif}

.pending-section{margin-top:16px}
.pending-grid{display:flex;flex-direction:column;gap:6px;margin-top:8px}
.pending-row{
  display:flex;align-items:center;gap:12px;padding:9px 13px;
  background:rgba(245,158,11,.04);border:1px solid rgba(245,158,11,.12);
  border-radius:9px;
}
.pending-row .pname{flex:1;font-size:12px;font-weight:700}
.pending-row .pfee{font-size:11px;color:#fbbf24;font-weight:700;font-family:'Outfit',sans-serif}
.btn-mark-paid{
  padding:5px 12px;border-radius:7px;
  background:rgba(16,185,129,.12);border:1px solid rgba(16,185,129,.22);
  color:#34d399;font-size:10.5px;font-weight:700;cursor:pointer;font-family:inherit;
  transition:all .15s;
}
.btn-mark-paid:hover{background:rgba(16,185,129,.22)}

/* Payment Modal */
#pay-modal .modal-title{color:#34d399}
#pay-modal .btn-save{background:linear-gradient(135deg,#10b981,#059669);box-shadow:0 4px 14px rgba(16,185,129,.3)}

/* ══════════════════════════════
   ALUMNI (পূর্বতন) STYLING
══════════════════════════════ */
.alumni-hero{
  background:linear-gradient(120deg,rgba(100,116,139,.09),rgba(71,85,105,.05));
  border:1px solid rgba(100,116,139,.18);border-radius:16px;
  padding:20px 24px;margin-bottom:16px;position:relative;overflow:hidden;
}
.alumni-hero::after{content:'\ud83d\udcc2';position:absolute;right:20px;top:50%;transform:translateY(-50%);font-size:52px;opacity:.07;pointer-events:none}
.alumni-hero h1{font-size:18px;font-weight:900;font-family:'Outfit',sans-serif;margin-bottom:4px}
.alumni-hero em{color:#94a3b8;font-style:normal}
.alumni-hero p{font-size:11.5px;color:var(--t2);line-height:1.7}

.alumni-card{
  background:rgba(100,116,139,.06);border:1px solid rgba(100,116,139,.14);border-radius:11px;
  padding:11px 14px;display:flex;align-items:center;gap:11px;
  transition:all .15s;
}
.alumni-card:hover{border-color:rgba(100,116,139,.25);background:rgba(100,116,139,.09)}
.alumni-avatar{
  width:36px;height:36px;border-radius:9px;flex-shrink:0;
  background:rgba(100,116,139,.15);border:1px solid rgba(100,116,139,.2);
  display:flex;align-items:center;justify-content:center;
  font-size:13px;font-weight:800;font-family:'Outfit',sans-serif;
  color:#94a3b8;
}
.alumni-name{font-size:12.5px;font-weight:700;color:var(--t2);margin-bottom:3px}
.alumni-date{font-size:10px;color:var(--t3)}
.btn-restore{
  padding:5px 11px;border-radius:7px;
  background:rgba(16,185,129,.08);border:1px solid rgba(16,185,129,.18);
  color:#34d399;font-size:10.5px;font-weight:700;cursor:pointer;font-family:inherit;
  transition:all .15s;white-space:nowrap;
}
.btn-restore:hover{background:rgba(16,185,129,.18)}
.btn-del-alumni{
  padding:5px 9px;border-radius:7px;
  background:rgba(244,63,94,.06);border:1px solid rgba(244,63,94,.15);
  color:var(--red);font-size:10.5px;cursor:pointer;font-family:inherit;transition:all .15s;
}
.btn-del-alumni:hover{background:rgba(244,63,94,.13)}
</style>
</head>
<body>

<!-- ── Navigation ── -->
<nav class="nav">
  <div class="brand">
    <div class="brand-icon">🕌</div>
    <div><div class="brand-name">GIC Control</div><div class="brand-sub">Global Islamic Care</div></div>
  </div>
  <button class="tab on" data-t="home"     onclick="go('home')"><span class="tab-ico">🏠</span> Home</button>
  <button class="tab"    data-t="students" onclick="go('students')"><span class="tab-ico">👥</span> Students</button>
  <button class="tab"    data-t="alumni"   onclick="go('alumni')"><span class="tab-ico">📂</span> Former Students</button>
  <div class="nav-div"></div>
  <button class="tab"    data-t="cls"     onclick="go('cls')"><span class="tab-ico">📱</span> Class Bot</button>
  <button class="tab"    data-t="daily"   onclick="go('daily')"><span class="tab-ico">📄</span> Daily Report</button>
  <button class="tab"    data-t="invoice" onclick="go('invoice')"><span class="tab-ico">🧾</span> Invoice</button>
  <div class="nav-div"></div>
  <button class="tab tab-v" data-t="extra" onclick="go('extra')"><span class="tab-ico">💬</span> Extra Message</button>
  <button class="tab tab-pay" data-t="payment" onclick="go('payment')"><span class="tab-ico">💰</span> Payments</button>
  <div class="nav-div"></div>
  <button class="tab tab-teacher" data-t="teachers" onclick="go('teachers')"><span class="tab-ico">👨‍🏫</span> Teachers</button>
  <div class="nav-right">
    <div class="wdot x" id="wd"></div>
    <div class="wst" id="ws">Connecting...</div>
    <div class="clk" id="clk">--:--</div>
  </div>
</nav>

<div class="cnt">
  <!-- ── HOME ── -->
  <div class="pnl on" id="pp-home">
    <div class="scroll-panel" id="ph">
      <div class="hw">

        <!-- Hero -->
        <div class="hero" style="margin-bottom:14px">
          <h1>Assalamu Alaikum, <em>GIC Admin</em> 👋</h1>
          <p>All tasks in one WhatsApp connection &mdash; class links, PDF reports, Extra Messages.</p>
        </div>

        <!-- 2-column grid -->
        <div class="home-grid">

          <!-- WhatsApp Status -->
          <div class="wa-card">
            <div class="wa-head">
              <div class="wa-icon">📱</div>
              <div>
                <div class="wa-title">WhatsApp Connection</div>
                <div class="wa-sub">CLS Bot + Report Bot &mdash; single connection</div>
              </div>
            </div>
            <div class="wa-badge wa-x" id="wa-badge">
              <span id="wa-dot" style="width:7px;height:7px;border-radius:50%;display:inline-block;background:var(--t3)"></span>
              &nbsp;<span id="wa-txt">Connecting...</span>
            </div>
            <div id="qr-area">
              <p>📲 Scan the QR code below with WhatsApp<br><small>WhatsApp &rarr; &#8942; &rarr; Linked Devices &rarr; Link a Device</small></p>
              <img id="qr-img" src="" alt="QR Code" style="max-width:180px">
            </div>
          </div>

          <!-- Tools -->
          <div class="card">
            <div class="sec" style="margin-top:0">🛠️ Tools</div>
            <div class="tools-grid">
              <button class="tool-btn" onclick="go('daily')">
                <span class="tool-icon">📄</span>
                <div><div class="tool-name">Daily Report</div><div class="tool-desc">Generate &amp; send reports</div></div>
              </button>
              <button class="tool-btn" onclick="go('invoice')">
                <span class="tool-icon">🧾</span>
                <div><div class="tool-name">Invoice</div><div class="tool-desc">Create invoices</div></div>
              </button>
              <button class="tool-btn" onclick="go('cls')">
                <span class="tool-icon">📱</span>
                <div><div class="tool-name">Class Bot</div><div class="tool-desc">Schedules &amp; links</div></div>
              </button>
              <button class="tool-btn" onclick="go('students')">
                <span class="tool-icon">👥</span>
                <div><div class="tool-name">Students</div><div class="tool-desc">Manage list</div></div>
              </button>
              <button class="tool-btn purple home-grid-full" onclick="go('extra')" style="grid-column:1/-1">
                <span class="tool-icon">💬</span>
                <div><div class="tool-name">Extra Message</div><div class="tool-desc">WhatsApp Broadcast</div></div>
              </button>
            </div>
          </div>

        </div>

        <!-- Live Log -->
        <div class="sec">📋 Live Log</div>
        <div class="log-box" id="lgb"><div style="color:var(--t3)">Loading...</div></div>
        <div class="tip"><span>✅</span><div><strong>Scan QR once</strong> &mdash; you won&apos;t need to do it again. If the bot stops, the session will reconnect automatically.</div></div>

      </div>
    </div>
  </div>

  <!-- ── STUDENTS ── -->
  <div class="pnl" id="pp-students">
    <div class="scroll-panel" id="ps">
      <div class="hw">
        <div class="hero" style="margin-bottom:16px;background:linear-gradient(120deg,rgba(16,185,129,.08),rgba(59,130,246,.04));border-color:rgba(16,185,129,.14)">
          <h1>👥 Student List — <em style="color:var(--green)">Add once, works everywhere</em></h1>
          <p>Adding a student here automatically shows them in Daily Report, Invoice, and Extra Message.</p>
        </div>
        <div class="stu-toolbar">
          <div class="stu-search">
            <span style="font-size:13px">🔍</span>
            <input type="text" id="stu-search-inp" placeholder="Search by name or phone..." oninput="filterStudents(this.value)">
          </div>
          <div style="display:flex;align-items:center;gap:6px;white-space:nowrap">
            <span style="font-size:11px;color:var(--t2)">Total</span>
            <span class="stu-count" id="stu-cnt">0</span>
          </div>
          <button class="btn-add" onclick="openAddStu()">+ Add Student</button>
        </div>
        <div id="stu-list" style="display:flex;flex-direction:column;gap:7px">
          <div style="color:var(--t3);font-size:12px;padding:24px;text-align:center">Loading...</div>
        </div>
      </div>
    </div>
    <!-- Modal -->
    <div class="modal-bg" id="stu-modal">
      <div class="modal-box">
        <div class="modal-title" id="sm-title">Add New Student</div>
        <input type="hidden" id="sm-id">
        <div class="field-group">
          <div class="field"><label>Name *</label><input id="sm-name" type="text" placeholder="Student name"></div>
          <div class="field"><label>Phone / WhatsApp *</label><input id="sm-phone" type="text" placeholder="01XXXXXXXXX"></div>
          <div class="field"><label>Phone / WhatsApp 2 (Optional)</label><input id="sm-phone2" type="text" placeholder="01XXXXXXXXX"></div>
          <div class="field"><label>Class / Batch</label><input id="sm-class" type="text" placeholder="e.g. Quran Batch A"></div>
          <div class="field"><label>Class Schedule</label><input id="sm-schedule" type="text" placeholder="e.g. 10:00 PM"></div>
          <div class="field"><label>Monthly Fee (Taka)</label><input id="sm-fee" type="number" placeholder="2500"></div>
          <div class="field"><label>Category</label>
            <select id="sm-cat">
              <option value="hifz">Hifz</option>
              <option value="nazera">Nazera</option>
              <option value="tajweed">Tajweed</option>
              <option value="other">Other</option>
            </select>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" onclick="closeStuModal()">Cancel</button>
          <button class="btn-save" onclick="saveStu()">&#10003; Save</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ── CLASS MANAGE BOT ── -->
  <div class="pnl" id="pp-cls">
    <div class="cov" id="cv-cls"><div class="sp"></div><span>Loading CLS Dashboard...</span></div>
    <iframe id="fr-cls" src="" onload="hcov('cv-cls')"></iframe>
  </div>

  <!-- ── DAILY REPORT ── -->
  <div class="pnl" id="pp-daily">
    <div class="cov" id="cv-daily"><div class="sp"></div><span>Loading Daily Report...</span></div>
    <iframe id="fr-daily" src="" onload="hcov('cv-daily')"></iframe>
  </div>

  <!-- ── INVOICE ── -->
  <div class="pnl" id="pp-invoice">
    <div class="cov" id="cv-invoice"><div class="sp"></div><span>Loading Invoice...</span></div>
    <iframe id="fr-invoice" src="" onload="hcov('cv-invoice')"></iframe>
  </div>

  <!-- ── EXTRA MESSAGE ── -->
  <div class="pnl" id="pp-extra">
    <div class="scroll-panel" id="pe">
      <div class="hw">
        <div class="em-hero">
          <h1>💬 Extra Message — <em>WhatsApp Broadcast</em></h1>
          <p>Send custom messages to specific parents or everyone on WhatsApp anytime.</p>
        </div>
        <div class="wa-alert" id="em-wa-alert" style="display:none">
          ⚠️ <span>WhatsApp not connected! Please scan the QR code first to send messages.</span>
        </div>
        <div class="em-card">
          <div class="em-card-title">✍️ Write Message</div>
          <textarea class="em-textarea" id="em-msg" placeholder="Write message here...&#10;e.g. Class will be off tomorrow." oninput="updateChar()"></textarea>
          <div class="em-char"><span id="em-char-count">0</span> characters</div>
        </div>
        <div class="em-card">
          <div class="em-card-title">👥 Select Recipients</div>
          <button class="em-all-btn sel" id="em-all-btn" onclick="toggleAll()">
            <span id="em-all-ico">☑️</span>
            <span>Send to all</span>
            <span id="em-all-count" style="margin-left:auto;font-size:10px;color:var(--t3)"></span>
          </button>
          <div class="em-checkbox-row" id="em-stu-list">
            <div style="color:var(--t3);font-size:12px;padding:12px;text-align:center">Loading...</div>
          </div>
        </div>
        <button class="btn-send" id="em-send-btn" onclick="sendExtraMsg()">
          <span>📤</span> <span id="em-send-label">Send Message</span>
        </button>
        <div class="em-result" id="em-result">
          <div class="em-result-title" id="em-result-title"></div>
          <div id="em-result-rows"></div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── TEACHERS ── -->
  <div class="pnl" id="pp-teachers">
    <div class="scroll-panel" id="pt">
      <div class="hw">
        <div class="teacher-hero">
          <h1>👨‍🏫 Teacher Management</h1>
          <p>Create a separate login for each teacher. Teachers can log into their own dashboard to generate student reports and invoices.</p>
        </div>

        <!-- Teacher Login Link Info -->
        <div class="teacher-link-box">
          <span style="font-size:18px;flex-shrink:0">🔗</span>
          <div>
            <div style="font-weight:700;color:var(--t);margin-bottom:4px">Teacher Login Link:</div>
            <div style="font-size:10.5px;color:var(--t2);margin-bottom:6px">Share this link with teachers — they will login with their username &amp; password.</div>
            <span class="teacher-link-url" onclick="copyTeacherLink()" title="Click to copy">
              🔗 <span id="teacher-link-text">http://localhost:3000/teacher/login</span>
            </span>
          </div>
        </div>

        <div class="teacher-toolbar">
          <div style="flex:1;font-size:11px;color:var(--t2)">Total <strong id="teacher-cnt" style="color:var(--gold)">0</strong> teachers</div>
          <button class="btn-add-teacher" onclick="openAddTeacher()">+ Add New Teacher</button>
        </div>

        <div id="teacher-list" style="display:flex;flex-direction:column;gap:8px">
          <div style="color:var(--t3);font-size:12px;padding:24px;text-align:center">Loading...</div>
        </div>
      </div>
    </div>

    <!-- Teacher Add/Edit Modal -->
    <div class="modal-bg" id="teacher-modal">
      <div class="modal-box" style="max-width:500px">
        <div class="modal-title" id="tm-title">Add New Teacher</div>
        <input type="hidden" id="tm-id">
        <div class="field-group">
          <div class="field"><label>Full Name *</label><input id="tm-name" type="text" placeholder="e.g. Maulana Abdul Karim"></div>
          <div class="field"><label>Username * (for login)</label><input id="tm-username" type="text" placeholder="e.g. teacher1" autocomplete="off"></div>
          <div class="field">
            <label>Password * <span id="tm-pass-hint" style="font-weight:400;color:var(--t3);text-transform:none">(required for new teacher)</span></label>
            <input id="tm-password" type="password" placeholder="Minimum 6 characters" autocomplete="new-password">
          </div>
          <div class="field"><label>Subject (Optional)</label><input id="tm-subject" type="text" placeholder="e.g. Quran Hifz, Tajweed"></div>
          <div class="field">
            <label>Assign Students</label>
            <div style="font-size:10px;color:var(--t3);margin-bottom:5px">Select the students this teacher will be responsible for</div>
            <div class="assign-list" id="tm-assign-list">
              <div style="color:var(--t3);font-size:11px;padding:8px;text-align:center">Loading students...</div>
            </div>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" onclick="closeTeacherModal()">Cancel</button>
          <button class="btn-save" onclick="saveTeacher()">&#10003; Save</button>
        </div>
      </div>
    </div>
  </div>

  <!-- ── ALUMNI (Former Students) ── -->
  <div class="pnl" id="pp-alumni">
    <div class="scroll-panel" id="pal">
      <div class="hw">
        <div class="alumni-hero">
          <h1>&#128194; Former Students</h1>
          <p>Students who have left the institute. You can restore them to the active list or permanently remove them.</p>
        </div>
        <div class="teacher-toolbar">
          <div style="flex:1;font-size:11px;color:var(--t2)">Total <strong id="alumni-cnt" style="color:#94a3b8">0</strong> former students</div>
        </div>
        <div id="alumni-list" style="display:flex;flex-direction:column;gap:7px">
          <div style="color:var(--t3);font-size:12px;padding:24px;text-align:center">Loading...</div>
        </div>
      </div>
    </div>
  </div>

  <!-- ── PAYMENT TRACKER ── -->
  <div class="pnl" id="pp-payment">
    <div class="scroll-panel" id="ppay">
      <div class="hw">
        <div class="payment-hero">
          <h1>💰 Payment Tracker — <em>Monthly Income</em></h1>
          <p>Track monthly fee payments — who has paid, total income, and who still owes.</p>
        </div>

        <!-- Month Selector + Summary -->
        <div class="pay-toolbar">
          <input type="month" class="month-picker" id="pay-month" onchange="loadPaymentData()">
          <button class="btn-add-pay" onclick="openPayModal()">+ Add Payment</button>
          <button class="btn-add-pay" style="background:linear-gradient(135deg,#3b82f6,#2563eb);box-shadow:0 4px 14px rgba(59,130,246,.3)" onclick="loadPaymentData()">🔄 Refresh</button>
        </div>

        <!-- Stats Row -->
        <div class="pay-summary" id="pay-summary">
          <div class="pay-stat income"><div class="pay-stat-val" id="ps-income">Tk 0</div><div class="pay-stat-lbl">Total Collected</div></div>
          <div class="pay-stat expected"><div class="pay-stat-val" id="ps-expected">Tk 0</div><div class="pay-stat-lbl">Expected Total</div></div>
          <div class="pay-stat paid"><div class="pay-stat-val" id="ps-paid">0</div><div class="pay-stat-lbl">Paid</div></div>
          <div class="pay-stat pending"><div class="pay-stat-val" id="ps-pending">0</div><div class="pay-stat-lbl">Pending</div></div>
        </div>

        <!-- Paid List -->
        <div class="sec">&#10003; Paid Students</div>
        <div style="overflow-x:auto;border-radius:11px;border:1px solid var(--border)">
          <table class="pay-table" id="pay-paid-table">
            <thead><tr><th>Student</th><th>Amount</th><th>Date</th><th>Note</th><th></th></tr></thead>
            <tbody id="pay-paid-body"><tr><td colspan="5" style="text-align:center;color:var(--t3);padding:20px">No payments recorded this month</td></tr></tbody>
          </table>
        </div>

        <!-- Pending List -->
        <div class="pending-section">
          <div class="sec">&#9203; Pending Students</div>
          <div class="pending-grid" id="pay-pending-grid">
            <div style="color:var(--t3);font-size:12px;padding:16px;text-align:center">Loading...</div>
          </div>
        </div>
      </div>
    </div>

    <!-- Payment Add Modal -->
    <div class="modal-bg" id="pay-modal">
      <div class="modal-box" style="max-width:420px">
        <div class="modal-title">&#128176; Add Payment</div>
        <div class="field-group">
          <div class="field">
            <label>Student *</label>
            <select id="pm-student" style="width:100%;padding:10px 12px;border-radius:9px;border:1px solid var(--border);background:var(--bg2);color:var(--t);font-size:12px;font-family:inherit;outline:none">
              <option value="">-- Select Student --</option>
            </select>
          </div>
          <div class="field"><label>Amount (Taka) *</label><input id="pm-amount" type="number" placeholder="2500"></div>
          <div class="field">
            <label>Month *</label>
            <input id="pm-month" type="month" style="width:100%;padding:10px 12px;border-radius:9px;border:1px solid var(--border);background:var(--bg2);color:var(--t);font-size:12px;font-family:inherit;outline:none">
          </div>
          <div class="field"><label>Note (Optional)</label><input id="pm-note" type="text" placeholder="e.g. Bank Transfer"></div>
        </div>
        <div class="modal-actions">
          <button class="btn-cancel" onclick="closePayModal()">Cancel</button>
          <button class="btn-save" onclick="savePayment()">&#10003; Save</button>
        </div>
      </div>
    </div>
  </div>

</div>

<div id="ts"></div>
<script>
// ── State ────────────────────────────────────────────────────
var _ld = {cls: false, daily: false, invoice: false};
var lastLog = null;
var _stuList = [];
var _sendAll = true;
var _selectedIds = [];

// ── Navigation ───────────────────────────────────────────────

function go(tabName) {
  var tabs = document.querySelectorAll('.tab');
  var panels = document.querySelectorAll('.pnl');
  for (var i = 0; i < tabs.length; i++) tabs[i].classList.remove('on');
  for (var i = 0; i < panels.length; i++) panels[i].classList.remove('on');

  var activeBtn = document.querySelector('[data-t="' + tabName + '"]');
  var activePanel = document.getElementById('pp-' + tabName);
  if (activeBtn) activeBtn.classList.add('on');
  if (activePanel) activePanel.classList.add('on');

  // Lazy-load iframes on first visit
  if (tabName === 'cls' && !_ld.cls) {
    _ld.cls = true;
    var fr = document.getElementById('fr-cls');
    if (fr) fr.src = '/tools/cls-dash/';
    setTimeout(function(){ hcov('cv-cls'); }, 2500);
  }
  if (tabName === 'daily' && !_ld.daily) {
    _ld.daily = true;
    var fr = document.getElementById('fr-daily');
    if (fr) fr.src = '/tools/report/daily-report-generator.html';
    setTimeout(function(){ hcov('cv-daily'); }, 2500);
  }
  if (tabName === 'invoice' && !_ld.invoice) {
    _ld.invoice = true;
    var fr = document.getElementById('fr-invoice');
    if (fr) fr.src = '/tools/invoice/invoice-generator.html';
    setTimeout(function(){ hcov('cv-invoice'); }, 2500);
  }
  if (tabName === 'students') loadStudents();
  if (tabName === 'extra') loadExtraStudents();
  if (tabName === 'teachers') loadTeachersAdmin();
  if (tabName === 'alumni') loadAlumni();
  if (tabName === 'payment') { initPaymentTab(); loadPaymentData(); }
}

// ── Toast ────────────────────────────────────────────────────
function toast(msg, col) {
  var ts = document.getElementById('ts');
  var div = document.createElement('div');
  div.className = 'tt';
  if (col) div.style.borderColor = col;
  div.textContent = msg;
  ts.appendChild(div);
  setTimeout(function() { if (div.parentNode) div.parentNode.removeChild(div); }, 3500);
}

// ── Load Students ────────────────────────────────────────────
function loadStudents() {
  fetch('/api/students').then(function(r) { return r.json(); }).then(function(data) {
    _stuList = data;
    renderStuList(_stuList);
    var cnt = document.getElementById('stu-cnt');
    if (cnt) cnt.textContent = _stuList.length;
  }).catch(function() {
    var el = document.getElementById('stu-list');
    if (el) el.innerHTML = '<div style="color:var(--red);font-size:12px;padding:20px;text-align:center">&#10060; Failed to load &mdash; Is GIC running?</div>';
  });
}

function filterStudents(q) {
  var list = q.trim()
    ? _stuList.filter(function(s) {
        return (s.name||'').toLowerCase().indexOf(q.toLowerCase()) >= 0 || (s.phone||'').indexOf(q) >= 0;
      })
    : _stuList;
  renderStuList(list);
}

function renderStuList(list) {
  var el = document.getElementById('stu-list');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div style="color:var(--t3);padding:28px;text-align:center;font-size:12px">No students found. Click the "+ Add Student" button above.</div>';
    return;
  }
  var avClass = {hifz:'av-hifz',nazera:'av-nazera',tajweed:'av-tajweed',other:'av-other'};
  var chipClass = {hifz:'chip-hifz',nazera:'chip-nazera',tajweed:'chip-tajweed',other:'chip-other'};
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var s = list[i];
    var ri = _stuList.indexOf(s);
    var cat = s.category || 'other';
    var initials = (s.name || '?').split(' ').map(function(w){return w[0];}).slice(0,2).join('').toUpperCase();
    var tags = [];
    if (s.phone) tags.push('\uD83D\uDCF1 ' + s.phone);
    if (s.phone2) tags.push('\uD83D\uDCF1\u2082 ' + s.phone2);
    if (s.class) tags.push('\uD83D\uDCDA ' + s.class);
    if (s.schedule) tags.push('\u23F0 ' + s.schedule);
    if (s.fee) tags.push('Tk ' + s.fee + '/mo');
    var tagHtml = '';
    for (var j = 0; j < tags.length; j++) tagHtml += '<span class="stu-tag">' + tags[j] + '</span>';
    if (s.category) tagHtml += '<span class="cat-chip ' + (chipClass[cat]||chipClass.other) + '">' + cat.toUpperCase() + '</span>';
    html += '<div class="stu-card">' +
      '<div class="stu-avatar ' + (avClass[cat]||avClass.other) + '">' + initials + '</div>' +
      '<div style="flex:1;min-width:0">' +
        '<div class="stu-name">' + (s.name || '\u2014') + '</div>' +
        '<div class="stu-tags">' + tagHtml + '</div>' +
      '</div>' +
      '<div style="display:flex;gap:6px;flex-shrink:0">' +
        '<button class="btn-edit" onclick="editStu(' + ri + ')">\u270F\uFE0F Edit</button>' +
        '<button style="padding:5px 9px;border-radius:7px;border:1px solid rgba(245,158,11,.2);background:rgba(245,158,11,.07);color:#f59e0b;font-size:10px;cursor:pointer;font-family:inherit;transition:all .15s" title="Move to Former Students" data-sid="' + s.id + '" onclick="archiveStu(this.dataset.sid, this.textContent)">&#128194;</button>' +
        '<button class="btn-del" onclick="deleteStu(' + ri + ')">\ud83d\uddd1\uFE0F</button>' +
      '</div>' +
    '</div>';

  }
  el.innerHTML = html;
}

function openAddStu() {
  document.getElementById('sm-title').textContent = 'Add New Student';
  document.getElementById('sm-id').value = '';
  ['sm-name','sm-phone','sm-phone2','sm-class','sm-schedule'].forEach(function(id) {
    document.getElementById(id).value = '';
  });
  document.getElementById('sm-fee').value = '';
  document.getElementById('sm-cat').value = 'hifz';
  document.getElementById('stu-modal').style.display = 'flex';
  setTimeout(function() { document.getElementById('sm-name').focus(); }, 100);
}

function editStu(i) {
  var s = _stuList[i];
  if (!s) return;
  document.getElementById('sm-title').textContent = 'Edit Student';
  document.getElementById('sm-id').value = i;
  document.getElementById('sm-name').value = s.name || '';
  document.getElementById('sm-phone').value = s.phone || '';
  document.getElementById('sm-phone2').value = s.phone2 || '';
  document.getElementById('sm-class').value = s.class || '';
  document.getElementById('sm-schedule').value = s.schedule || '';
  document.getElementById('sm-fee').value = s.fee || '';
  document.getElementById('sm-cat').value = s.category || 'hifz';
  document.getElementById('stu-modal').style.display = 'flex';
}

function closeStuModal() {
  document.getElementById('stu-modal').style.display = 'none';
}

function saveStu() {
  var name  = document.getElementById('sm-name').value.trim();
  var phone = document.getElementById('sm-phone').value.trim().replace(/\D/g,'');
  var phone2= document.getElementById('sm-phone2').value.trim().replace(/\D/g,'');
  if (!name) { toast('\u274C Please enter a name!', 'var(--red)'); return; }
  var idx = document.getElementById('sm-id').value;
  var stu = {
    id: idx === '' ? 'stu_' + Date.now() : (_stuList[idx] && _stuList[idx].id ? _stuList[idx].id : 'stu_' + Date.now()),
    name: name, phone: phone,
    phone2: phone2 || undefined,
    class: document.getElementById('sm-class').value.trim(),
    schedule: document.getElementById('sm-schedule').value.trim(),
    fee: document.getElementById('sm-fee').value ? Number(document.getElementById('sm-fee').value) : undefined,
    category: document.getElementById('sm-cat').value
  };
  if (idx === '') _stuList.push(stu);
  else _stuList[idx] = stu;
  fetch('/api/students', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({students: _stuList})})
    .then(function() {
      closeStuModal();
      renderStuList(_stuList);
      var cnt = document.getElementById('stu-cnt');
      if (cnt) cnt.textContent = _stuList.length;
      toast('\u2705 Student saved successfully!');
    })
    .catch(function() { toast('\u274C Failed to save!', 'var(--red)'); });
}

function deleteStu(i) {
  if (!_stuList[i]) return;
  if (!confirm(_stuList[i].name + ' \u2014 Delete this student?')) return;
  var removed = _stuList.splice(i, 1);
  fetch('/api/students', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({students: _stuList})})
    .then(function(r) {
      if (!r.ok) throw new Error('Server error');
      renderStuList(_stuList);
      var cnt = document.getElementById('stu-cnt');
      if (cnt) cnt.textContent = _stuList.length;
      toast('\uD83D\uDDD1\uFE0F Student deleted');
    })
    .catch(function() {
      // Bug fix: restore item on server error and re-render
      _stuList.splice(i, 0, removed[0]);
      renderStuList(_stuList);
      toast('\u274C Failed to delete! Please try again.', 'var(--red)');
    });
}

// ── Extra Message ────────────────────────────────────────────
function loadExtraStudents() {
  fetch('/api/students').then(function(r) { return r.json(); }).then(function(students) {
    renderExtraStudents(students);
    var el = document.getElementById('em-all-count');
    if (el) el.textContent = 'Total ' + students.length + ' students';
  }).catch(function(){});
}

function renderExtraStudents(students) {
  var el = document.getElementById('em-stu-list');
  if (!el) return;
  if (!students.length) {
    el.innerHTML = '<div style="color:var(--t3);font-size:12px;padding:12px;text-align:center">No students found. Add them in the Students tab first.</div>';
    return;
  }
  _selectedIds = students.map(function(s) { return s.id; });
  var html = '';
  for (var i = 0; i < students.length; i++) {
    var s = students[i];
    // Bug fix: escape single-quotes in onclick to avoid broken data-id attribute
    // Old broken code: onclick="toggleStu(\'sid\',this)" → broken HTML
    html += '<label class="em-stu-cb sel" id="cb-row-' + s.id + '" data-sid="' + s.id + '" onclick="toggleStu(this.dataset.sid,this)">' +
      '<input type="checkbox" id="cb-' + s.id + '" checked>' +
      '<div style="flex:1">' +
        '<div class="em-stu-cb-name">' + (s.name || '\u2014') + '</div>' +
        '<div class="em-stu-cb-phone">' + (s.phone ? '\uD83D\uDCF1 ' + s.phone : '') + (s.phone2 ? ' \u00B7 ' + s.phone2 : '') + '</div>' +
      '</div>' +
    '</label>';
  }
  el.innerHTML = html;
}

function toggleStu(sid, input) {
  var row = document.getElementById('cb-row-' + sid);
  var idx = _selectedIds.indexOf(sid);
  if (input.checked) {
    if (idx < 0) _selectedIds.push(sid);
    if (row) row.classList.add('sel');
  } else {
    if (idx >= 0) _selectedIds.splice(idx, 1);
    if (row) row.classList.remove('sel');
  }
  syncAllBtn();
}

function toggleAll() {
  _sendAll = !_sendAll;
  var btn = document.getElementById('em-all-btn');
  var boxes = document.querySelectorAll('#em-stu-list input[type=checkbox]');
  var rows = document.querySelectorAll('.em-stu-cb');
  var icoEl = document.getElementById('em-all-ico');
  if (_sendAll) {
    if (btn) btn.classList.add('sel');
    if (icoEl) icoEl.textContent = '\u2611\uFE0F';
    _selectedIds = [];
    for (var i = 0; i < boxes.length; i++) {
      boxes[i].checked = true;
      _selectedIds.push(boxes[i].id.replace('cb-',''));
    }
    for (var i = 0; i < rows.length; i++) rows[i].classList.add('sel');
  } else {
    if (btn) btn.classList.remove('sel');
    if (icoEl) icoEl.textContent = '\u2B1C';
    for (var i = 0; i < boxes.length; i++) boxes[i].checked = false;
    for (var i = 0; i < rows.length; i++) rows[i].classList.remove('sel');
    _selectedIds = [];
  }
}

function syncAllBtn() {
  var boxes = document.querySelectorAll('#em-stu-list input[type=checkbox]');
  var allChecked = true;
  for (var i = 0; i < boxes.length; i++) { if (!boxes[i].checked) { allChecked = false; break; } }
  _sendAll = allChecked;
  var btn = document.getElementById('em-all-btn');
  var ico = document.getElementById('em-all-ico');
  if (allChecked) { if (btn) btn.classList.add('sel'); if (ico) ico.textContent = '\u2611\uFE0F'; }
  else { if (btn) btn.classList.remove('sel'); if (ico) ico.textContent = '\u2B1C'; }
}

function updateChar() {
  var msg = document.getElementById('em-msg');
  var cnt = document.getElementById('em-char-count');
  if (msg && cnt) cnt.textContent = msg.value.length;
}

function sendExtraMsg() {
  var msgEl = document.getElementById('em-msg');
  var msg = msgEl ? msgEl.value.trim() : '';
  if (!msg) { toast('\u274C Please write a message!', 'var(--red)'); return; }
  if (!_sendAll && !_selectedIds.length) { toast('\u274C Select at least one recipient!', 'var(--red)'); return; }
  var btn = document.getElementById('em-send-btn');
  var lbl = document.getElementById('em-send-label');
  if (btn) btn.disabled = true;
  if (lbl) lbl.textContent = 'Sending...';
  var targets = _sendAll ? 'all' : _selectedIds.slice();
  fetch('/api/send-message', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({message: msg, targets: targets})})
    .then(function(r) { return r.json(); })
    .then(function(data) {
      var rEl = document.getElementById('em-result');
      var rTitle = document.getElementById('em-result-title');
      var rRows = document.getElementById('em-result-rows');
      if (data.success) {
        if (rEl) { rEl.className = 'em-result ok'; rEl.style.display = 'block'; }
        if (rTitle) rTitle.textContent = '\u2705 ' + data.summary;
        if (rRows && data.results) {
          var rh = '';
          for (var i = 0; i < data.results.length; i++) {
            var rr = data.results[i];
            rh += '<div class="em-result-row">' + (rr.ok ? '<span style="color:var(--green)">\u2705</span>' : '<span style="color:var(--red)">\u274C</span>') +
              '<span>' + (rr.name||'\u2014') + '</span>' + (rr.phone ? '<span style="color:var(--t3)">' + rr.phone + '</span>' : '') + '</div>';
          }
          rRows.innerHTML = rh;
        }
        toast('\u2705 Message sent successfully!');
      } else {
        if (rEl) { rEl.className = 'em-result err'; rEl.style.display = 'block'; }
        if (rTitle) rTitle.textContent = '\u274C ' + (data.error || 'Error');
        if (rRows) rRows.innerHTML = '';
        toast('\u274C ' + (data.error||'Error'), 'var(--red)');
      }
    })
    .catch(function() { toast('\u274C Network error!', 'var(--red)'); })
    .finally(function() {
      if (btn) btn.disabled = false;
      if (lbl) lbl.textContent = 'Send Message';
    });
}

function hcov(id) {
  var el = document.getElementById(id);
  if (el) el.classList.add('h');
}

// ── Clock ────────────────────────────────────────────────────
// Bug fix: use Asia/Dhaka timezone to match server-side date
setInterval(function() {
  var el = document.getElementById('clk');
  if (el) el.textContent = new Date().toLocaleTimeString('en-US', {timeZone:'Asia/Dhaka', hour:'2-digit', minute:'2-digit', hour12:true});
}, 1000);

// ── WhatsApp Poll ────────────────────────────────────────────
function poll() {
  fetch('/api/status').then(function(r) { return r.json(); }).then(function(d) {
    var wd = document.getElementById('wd');
    var ws = document.getElementById('ws');
    var wb = document.getElementById('wa-badge');
    var wt = document.getElementById('wa-txt');
    var qra = document.getElementById('qr-area');
    var emAlert = document.getElementById('em-wa-alert');
    if (d.ready) {
      if (wd) wd.className = 'wdot g';
      if (ws) ws.textContent = '\u2705 Connected';
      if (wb) wb.className = 'wa-badge wa-r';
      if (wt) wt.textContent = '\u2705 Connected & Ready';
      if (qra) qra.style.display = 'none';
      if (emAlert) emAlert.style.display = 'none';
    } else if (d.status === 'qr') {
      if (wd) wd.className = 'wdot y';
      if (ws) ws.textContent = '\uD83D\uDCF1 Scan QR Code';
      if (wb) wb.className = 'wa-badge wa-y';
      if (wt) wt.textContent = '\uD83D\uDCF1 Scan QR Code';
      if (qra) qra.style.display = 'block';
      var qrImg = document.getElementById('qr-img');
      if (qrImg) qrImg.src = '/api/qr-image?t=' + Date.now();
      if (emAlert) emAlert.style.display = 'flex';
    } else {
      if (wd) wd.className = 'wdot x';
      if (ws) ws.textContent = '\u23F3 Connecting...';
      if (wb) wb.className = 'wa-badge wa-x';
      if (wt) wt.textContent = 'Connecting...';
      if (qra) qra.style.display = 'none';
      if (emAlert) emAlert.style.display = 'flex';
    }
  }).catch(function(){});
}

// ── Live Log Poll ────────────────────────────────────────────
function pollLog() {
  var url = lastLog ? '/api/logs?since=' + lastLog : '/api/logs';
  fetch(url).then(function(r) { return r.json(); }).then(function(data) {
    if (!data.length) {
      // Remove loading placeholder if no logs on first load
      if (!lastLog) { var b0=document.getElementById('lgb'); if(b0){var ph0=b0.querySelector('[style*="color:var(--t3)"]');if(ph0)ph0.textContent='No logs yet.';} }
      return;
    }
    lastLog = data[data.length-1].time;
    var b = document.getElementById('lgb');
    if (!b) return;
    var atB = b.scrollHeight - b.clientHeight <= b.scrollTop + 8;
    var tc = {info:'li', success:'ls', error:'lr', warn:'lw'};
    for (var i = 0; i < data.length; i++) {
      var l = data[i];
      var row = document.createElement('div');
      row.className = 'le';
      row.innerHTML = '<span class="lt">' + new Date(l.time).toLocaleTimeString('en-US',{timeZone:'Asia/Dhaka'}) + '</span><span class="' + (tc[l.type]||'li') + '">' + l.msg + '</span>';
      b.appendChild(row);
    }
    if (atB) b.scrollTop = b.scrollHeight;
    var ph = b.querySelector('[style*="color:var(--t3)"]');
    if (ph) ph.parentNode.removeChild(ph);
  }).catch(function(){});
}

// ── Init ──────────────────────────────────────────────
poll();
pollLog();
setInterval(poll, 4000);
setInterval(pollLog, 3000);
setTimeout(function() { toast('\u2705 GIC is running! Scan the QR code once.'); }, 600);

// ── Teachers Admin ─────────────────────────────────────────
var _teacherList = [];
var _teacherAssignIds = [];

function copyTeacherLink() {
  var url = window.location.protocol + '//' + window.location.host + '/teacher/login';
  var el = document.getElementById('teacher-link-text');
  if (el) el.textContent = url;
  if (navigator.clipboard) {
    navigator.clipboard.writeText(url).then(function() { toast('\u2705 Link copied!'); });
  }
}

function loadTeachersAdmin() {
  fetch('/api/admin/teachers').then(function(r) { return r.json(); }).then(function(data) {
    _teacherList = data;
    renderTeacherList(data);
    var cnt = document.getElementById('teacher-cnt');
    if (cnt) cnt.textContent = data.length;
  }).catch(function() {
    var el = document.getElementById('teacher-list');
    if (el) el.innerHTML = '<div style="color:var(--red);font-size:12px;padding:20px;text-align:center">&#10060; Failed to load</div>';
  });
}

function renderTeacherList(list) {
  var el = document.getElementById('teacher-list');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div style="color:var(--t3);padding:32px;text-align:center;font-size:12px">' +
      '<div style="font-size:40px;opacity:.3;margin-bottom:10px">👨‍🏫</div>' +
      '<div>No teachers added yet. Click the "+ Add New Teacher" button above.</div>' +
    '</div>';
    return;
  }
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var t = list[i];
    var initials = (t.name || '?').split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase();
    var sCount = t.studentIds ? t.studentIds.length : 0;
    html += '<div class="teacher-card">' +
      '<div class="teacher-avatar">' + initials + '</div>' +
      '<div style="flex:1;min-width:0">' +
        '<div class="teacher-name">' + (t.name || '—') + '</div>' +
        '<div class="teacher-tags">' +
          '<span class="teacher-tag">👤 ' + (t.username || '') + '</span>' +
          (t.subject ? '<span class="teacher-tag">📚 ' + t.subject + '</span>' : '') +
          '<span class="teacher-count-badge">&#128101; ' + sCount + ' students</span>' +
          '<span class="teacher-tag" style="color:var(--t3)">📅 ' + (t.createdAt || '') + '</span>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;gap:6px;flex-shrink:0">' +
        '<button class="btn-edit" onclick="editTeacher(' + i + ')">✏️ Edit</button>' +
        '<button class="btn-del" data-tid="' + t.id + '" data-tname="' + (t.name||'').replace(/"/g,'&quot;') + '" onclick="deleteTeacher(this.dataset.tid, this.dataset.tname)">🗑️</button>' +
      '</div>' +
    '</div>';
  }
  el.innerHTML = html;
}

function openAddTeacher() {
  document.getElementById('tm-title').textContent = 'Add New Teacher';
  document.getElementById('tm-id').value = '';
  document.getElementById('tm-name').value = '';
  document.getElementById('tm-username').value = '';
  document.getElementById('tm-password').value = '';
  document.getElementById('tm-subject').value = '';
  var hint = document.getElementById('tm-pass-hint');
  if (hint) hint.textContent = '(required for new teacher)';
  _teacherAssignIds = [];
  loadAssignStudents([]);
  document.getElementById('teacher-modal').style.display = 'flex';
  setTimeout(function() { document.getElementById('tm-name').focus(); }, 100);
}

function editTeacher(i) {
  var t = _teacherList[i];
  if (!t) return;
  document.getElementById('tm-title').textContent = 'Edit Teacher';
  document.getElementById('tm-id').value = t.id;
  document.getElementById('tm-name').value = t.name || '';
  document.getElementById('tm-username').value = t.username || '';
  document.getElementById('tm-password').value = '';
  document.getElementById('tm-subject').value = t.subject || '';
  var hint = document.getElementById('tm-pass-hint');
  if (hint) hint.textContent = '(Leave blank to keep current password)';
  _teacherAssignIds = t.studentIds ? t.studentIds.slice() : [];
  loadAssignStudents(_teacherAssignIds);
  document.getElementById('teacher-modal').style.display = 'flex';
}

function loadAssignStudents(selectedIds) {
  var el = document.getElementById('tm-assign-list');
  if (!el) return;
  fetch('/api/students').then(function(r) { return r.json(); }).then(function(students) {
    if (!students.length) {
      el.innerHTML = '<div style="color:var(--t3);font-size:11px;padding:10px;text-align:center">No students — Add students in the Students tab first</div>';
      return;
    }
    var html = '';
    for (var i = 0; i < students.length; i++) {
      var s = students[i];
      var checked = selectedIds.indexOf(s.id) >= 0;
      html += '<label class="assign-row' + (checked ? ' sel' : '') + '" data-sid="' + s.id + '" onclick="toggleAssign(this.dataset.sid, this)">' +
        '<input type="checkbox" id="acb-' + s.id + '"' + (checked ? ' checked' : '') + '>' +
        '<div style="flex:1"><div class="assign-name">' + (s.name || '—') + '</div>' +
        '<div class="assign-phone">' + (s.phone ? '📱 ' + s.phone : '') + (s.class ? ' · ' + s.class : '') + '</div></div>' +
      '</label>';
    }
    el.innerHTML = html;
  }).catch(function() {
    el.innerHTML = '<div style="color:var(--red);font-size:11px;padding:8px">&#10060; Failed to load</div>';
  });
}

function toggleAssign(sid, row) {
  var cb = document.getElementById('acb-' + sid);
  if (!cb) return;
  setTimeout(function() {
    var idx = _teacherAssignIds.indexOf(sid);
    if (cb.checked) { if (idx < 0) _teacherAssignIds.push(sid); row.classList.add('sel'); }
    else { if (idx >= 0) _teacherAssignIds.splice(idx, 1); row.classList.remove('sel'); }
  }, 0);
}

function closeTeacherModal() {
  document.getElementById('teacher-modal').style.display = 'none';
}

function saveTeacher() {
  var name     = document.getElementById('tm-name').value.trim();
  var username = document.getElementById('tm-username').value.trim();
  var password = document.getElementById('tm-password').value;
  var subject  = document.getElementById('tm-subject').value.trim();
  var id       = document.getElementById('tm-id').value;
  if (!name) { toast('❌ Please enter a name!', 'var(--red)'); return; }
  if (!username) { toast('❌ Please enter a Username!', 'var(--red)'); return; }
  if (!id && !password) { toast('❌ Password is required for new teacher!', 'var(--red)'); return; }
  if (password && password.length < 6) { toast('&#10060; Password must be at least 6 characters!', 'var(--red)'); return; }
  var body = { name: name, username: username, subject: subject, studentIds: _teacherAssignIds.slice() };
  if (password) body.password = password;
  var url = id ? '/api/admin/teachers/' + id : '/api/admin/teachers';
  var method = id ? 'PUT' : 'POST';
  fetch(url, { method: method, headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.error) { toast('❌ ' + data.error, 'var(--red)'); return; }
      closeTeacherModal();
      loadTeachersAdmin();
      toast('✅ Teacher ' + (id ? 'updated' : 'added') + ' successfully!');
    })
    .catch(function() { toast('❌ Failed to save!', 'var(--red)'); });
}

function deleteTeacher(tid, tname) {
  if (!confirm(tname + ' — Delete this teacher?')) return;
  fetch('/api/admin/teachers/' + tid, { method: 'DELETE' })
    .then(function(r) { return r.json(); })
    .then(function(data) {
      if (data.error) { toast('❌ ' + data.error, 'var(--red)'); return; }
      loadTeachersAdmin();
      toast('🗑️ Teacher deleted');
    })
    .catch(function() { toast('❌ Failed to delete!', 'var(--red)'); });
}

// ── Alumni Management ─────────────────────────────────────
var _alumniList = [];

function archiveStu(sid, sname) {
  if (!confirm('Move ' + (sname || 'this student') + ' to Former Students list?')) return;
  fetch('/api/students/' + sid + '/archive', { method: 'POST' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.success) {
        toast('📂 Student moved to Former Students');
        loadStudents();
      } else {
        toast('❌ ' + (d.error || 'Failed to archive'), 'var(--red)');
      }
    })
    .catch(function() { toast('❌ Network error', 'var(--red)'); });
}

function loadAlumni() {
  fetch('/api/students/alumni')
    .then(function(r) { return r.json(); })
    .then(function(data) {
      _alumniList = data;
      renderAlumni(_alumniList);
      var cnt = document.getElementById('alumni-cnt');
      if (cnt) cnt.textContent = data.length;
    })
    .catch(function() {
      var el = document.getElementById('alumni-list');
      if (el) el.innerHTML = '<div style="color:var(--red);font-size:12px;padding:20px;text-align:center">❌ Failed to load alumni</div>';
    });
}

function renderAlumni(list) {
  var el = document.getElementById('alumni-list');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div style="color:var(--t3);padding:32px;text-align:center;font-size:12px">' +
      '<div style="font-size:40px;opacity:.3;margin-bottom:10px">📂</div>' +
      '<div>No former students recorded.</div></div>';
    return;
  }
  var html = '';
  for (var i = 0; i < list.length; i++) {
    var s = list[i];
    var initials = (s.name || '?').split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase();
    html += '<div class="alumni-card">' +
      '<div class="alumni-avatar">' + initials + '</div>' +
      '<div style="flex:1;min-width:0">' +
        '<div class="alumni-name">' + (s.name || '—') + '</div>' +
        '<div class="alumni-tags">' +
          (s.phone ? '<span class="alumni-tag">📱 ' + s.phone + '</span>' : '') +
          (s.class ? '<span class="alumni-tag">📚 ' + s.class + '</span>' : '') +
          (s.archivedAt ? '<span class="alumni-tag" style="color:var(--t3)">📅 Left: ' + s.archivedAt + '</span>' : '') +
        '</div>' +
      '</div>' +
      '<div style="display:flex;gap:6px;flex-shrink:0">' +
        '<button class="btn-restore-alumni" data-sid="' + s.id + '" data-sname="' + (s.name||'').replace(/"/g,'&quot;') + '" onclick="restoreAlumni(this.dataset.sid, this.dataset.sname)">🔄 Restore</button>' +
        '<button class="btn-del-alumni" data-sid="' + s.id + '" data-sname="' + (s.name||'').replace(/"/g,'&quot;') + '" onclick="deleteAlumniPermanent(this.dataset.sid, this.dataset.sname)">🗑️ Delete</button>' +
      '</div>' +
    '</div>';
  }
  el.innerHTML = html;
}

function restoreAlumni(sid, sname) {
  if (!confirm('Restore ' + (sname || 'this student') + ' to active student list?')) return;
  fetch('/api/students/' + sid + '/restore', { method: 'POST' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.success) {
        toast('✅ Student restored to active list!');
        loadAlumni();
      } else {
        toast('❌ ' + (d.error || 'Failed to restore'), 'var(--red)');
      }
    })
    .catch(function() { toast('❌ Network error', 'var(--red)'); });
}

function deleteAlumniPermanent(sid, sname) {
  if (!confirm('Permanently delete ' + (sname || 'this student') + '? This cannot be undone.')) return;
  fetch('/api/students/alumni/' + sid, { method: 'DELETE' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      toast('🗑️ Student deleted');
      loadAlumni();
    })
    .catch(function() {
      toast('❌ Network error', 'var(--red)');
    });
}

// ── Payment Tracker Management ────────────────────────────
function getCurrentMonth() {
  var now = new Date();
  var y = now.getFullYear();
  var m = String(now.getMonth() + 1).padStart(2, '0');
  return y + '-' + m;
}

function initPaymentTab() {
  var mInp = document.getElementById('pay-month');
  if (mInp && !mInp.value) {
    mInp.value = getCurrentMonth();
  }
}

function loadPaymentData() {
  var mInp = document.getElementById('pay-month');
  var month = mInp ? mInp.value : getCurrentMonth();
  if (!month) month = getCurrentMonth();

  fetch('/api/payments?month=' + month)
    .then(function(r) { return r.json(); })
    .then(function(data) {
      renderPaymentPanel(data);
    })
    .catch(function() {
      var grid = document.getElementById('pay-grid');
      if (grid) grid.innerHTML = '<div style="color:var(--red);font-size:12px;padding:20px;text-align:center;grid-column:1/-1">❌ Failed to load payment data</div>';
    });

  fetch('/api/payments/summary/' + month)
    .then(function(r) { return r.json(); })
    .then(function(s) {
      var incEl = document.getElementById('stat-month-income');
      var paidEl = document.getElementById('stat-paid-count');
      var unpEl = document.getElementById('stat-unpaid-count');
      if (incEl) incEl.textContent = 'Tk ' + (s.totalIncome || 0);
      if (paidEl) paidEl.textContent = s.paidCount || 0;
      if (unpEl) unpEl.textContent = s.unpaidCount || 0;
    }).catch(function(){});
}

function renderPaymentPanel(data) {
  var grid = document.getElementById('pay-grid');
  if (!grid) return;
  var students = data.students || [];
  var payments = data.payments || [];

  if (!students.length) {
    grid.innerHTML = '<div style="color:var(--t3);padding:32px;text-align:center;font-size:12px;grid-column:1/-1">' +
      '<div style="font-size:40px;opacity:.3;margin-bottom:10px">💰</div>' +
      '<div>No active students found. Add students in the Students tab first.</div></div>';
    return;
  }

  var payMap = {};
  for (var i = 0; i < payments.length; i++) {
    payMap[payments[i].studentId] = payments[i];
  }

  var html = '';
  for (var i = 0; i < students.length; i++) {
    var s = students[i];
    var p = payMap[s.id];
    var isPaid = !!p;
    var fee = s.fee || 0;
    var initials = (s.name || '?').split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase();

    html += '<div class="pay-card ' + (isPaid ? 'paid' : 'due') + '">' +
      '<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">' +
        '<div style="width:38px;height:38px;border-radius:10px;background:' + (isPaid ? 'rgba(16,185,129,.12)' : 'rgba(244,63,94,.12)') + ';color:' + (isPaid ? 'var(--green)' : 'var(--red)') + ';display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px">' + initials + '</div>' +
        '<div style="flex:1;min-width:0">' +
          '<div style="font-size:13px;font-weight:700;color:var(--t);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + (s.name || '—') + '</div>' +
          '<div style="font-size:10px;color:var(--t2)">' + (s.class ? s.class + ' · ' : '') + 'Tk ' + fee + '/mo</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;align-items:center;justify-content:space-between;padding-top:8px;border-top:1px solid rgba(255,255,255,.05)">' +
        (isPaid
          ? '<span class="pay-status-badge pay-paid">✅ Paid: Tk ' + p.amount + '</span>' +
            '<button class="btn-del-pay" data-pid="' + p.id + '" data-sname="' + (s.name||'').replace(/"/g,'&quot;') + '" onclick="deletePayment(this.dataset.pid, this.dataset.sname)">🗑️ Delete</button>'
          : '<span class="pay-status-badge pay-due">⚠️ Unpaid</span>' +
            '<button class="btn-mark-paid" data-sid="' + s.id + '" data-fee="' + fee + '" onclick="quickMarkPaid(this.dataset.sid, this.dataset.fee)">💰 Mark Paid</button>'
        ) +
      '</div>' +
    '</div>';
  }
  grid.innerHTML = html;
}

function quickMarkPaid(studentId, amount) {
  var mInp = document.getElementById('pay-month');
  var month = mInp ? mInp.value : getCurrentMonth();
  if (!month) month = getCurrentMonth();

  fetch('/api/payments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ studentId: studentId, amount: Number(amount) || 0, month: month, note: 'Quick Mark Paid' })
  })
  .then(function(r) { return r.json(); })
  .then(function(d) {
    if (d.error) { toast('❌ ' + d.error, 'var(--red)'); return; }
    toast('✅ Marked as Paid!');
    loadPaymentData();
  })
  .catch(function() { toast('❌ Network error', 'var(--red)'); });
}

function openPayModal() {
  var sel = document.getElementById('pm-student');
  var mInp = document.getElementById('pm-month');
  if (mInp && !mInp.value) mInp.value = getCurrentMonth();
  document.getElementById('pm-amount').value = '';
  document.getElementById('pm-note').value = '';

  if (sel) {
    sel.innerHTML = '<option value="">-- Loading students... --</option>';
    fetch('/api/students').then(function(r){ return r.json(); }).then(function(list) {
      var opts = '<option value="">-- Select Student --</option>';
      for (var i = 0; i < list.length; i++) {
        opts += '<option value="' + list[i].id + '">' + list[i].name + (list[i].fee ? ' (Tk ' + list[i].fee + ')' : '') + '</option>';
      }
      sel.innerHTML = opts;
    }).catch(function() {
      sel.innerHTML = '<option value="">-- Failed to load --</option>';
    });
  }
  document.getElementById('pay-modal').style.display = 'flex';
}

function closePayModal() {
  document.getElementById('pay-modal').style.display = 'none';
}

function savePayment() {
  var sId = document.getElementById('pm-student').value;
  var amt = document.getElementById('pm-amount').value;
  var month = document.getElementById('pm-month').value;
  var note = document.getElementById('pm-note').value.trim();

  if (!sId) { toast('❌ Select a student!', 'var(--red)'); return; }
  if (!amt || Number(amt) <= 0) { toast('❌ Enter payment amount!', 'var(--red)'); return; }
  if (!month) { toast('❌ Select month!', 'var(--red)'); return; }

  fetch('/api/payments', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ studentId: sId, amount: Number(amt), month: month, note: note })
  })
  .then(function(r) { return r.json(); })
  .then(function(d) {
    if (d.error) { toast('❌ ' + d.error, 'var(--red)'); return; }
    closePayModal();
    toast('✅ Payment recorded successfully!');
    loadPaymentData();
  })
  .catch(function() { toast('❌ Network error', 'var(--red)'); });
}

function deletePayment(payId, sname) {
  if (!confirm('Delete payment record for ' + (sname || 'this student') + '?')) return;
  fetch('/api/payments/' + payId, { method: 'DELETE' })
    .then(function(r) { return r.json(); })
    .then(function(d) {
      if (d.error) { toast('❌ ' + d.error, 'var(--red)'); return; }
      toast('🗑️ Payment deleted');
      loadPaymentData();
    })
    .catch(function() { toast('❌ Network error', 'var(--red)'); });
}
</script>
</body>
</html>`;



// ════════════════════════════════════════════════════════════════
//  TEACHER LOGIN PAGE
// ════════════════════════════════════════════════════════════════
const TEACHER_LOGIN_PAGE = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>GIC &mdash; Teacher Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Outfit:wght@600;700;800;900&family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#04080f;--bg2:#090f1c;--bg3:#0e1828;
  --gold:#f5c842;--gold2:#d97706;
  --green:#10b981;--red:#f43f5e;--amber:#f59e0b;
  --t:#e8edf5;--t2:#8fa3bf;--t3:#4a5a72;
  --border:rgba(255,255,255,.08);
}
html,body{height:100%;font-family:'Inter','Hind Siliguri',sans-serif;background:var(--bg);color:var(--t)}
body{display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden}
body::before{
  content:'';position:fixed;inset:0;pointer-events:none;
  background:
    radial-gradient(ellipse 70% 55% at 20% 10%,rgba(245,200,66,.05),transparent),
    radial-gradient(ellipse 60% 50% at 80% 90%,rgba(16,185,129,.04),transparent),
    radial-gradient(ellipse 40% 40% at 50% 50%,rgba(59,130,246,.03),transparent);
}
.login-wrap{
  width:100%;max-width:420px;padding:20px;position:relative;z-index:1;
}
.login-brand{text-align:center;margin-bottom:28px}
.login-icon{
  width:64px;height:64px;border-radius:18px;margin:0 auto 12px;
  background:linear-gradient(135deg,#f5c842,#d97706);
  display:flex;align-items:center;justify-content:center;font-size:28px;
  box-shadow:0 0 32px rgba(245,200,66,.4);
}
.login-title{font-size:22px;font-weight:900;font-family:'Outfit',sans-serif;letter-spacing:-.3px}
.login-sub{font-size:12px;color:var(--t2);margin-top:5px;letter-spacing:.5px}
.login-card{
  background:linear-gradient(160deg,rgba(14,24,40,.98),rgba(9,15,28,.97));
  border:1px solid rgba(255,255,255,.08);border-radius:20px;
  padding:32px 30px;
  box-shadow:0 30px 80px rgba(0,0,0,.7),0 0 0 1px rgba(255,255,255,.04),
    inset 0 1px 0 rgba(255,255,255,.06);
  backdrop-filter:blur(20px);
}
.login-card::before{
  content:'';position:absolute;top:0;left:50%;transform:translateX(-50%);
  width:60%;height:1px;
  background:linear-gradient(90deg,transparent,rgba(245,200,66,.3),transparent);
}
.field{margin-bottom:16px}
.field label{
  display:block;font-size:10.5px;font-weight:700;
  text-transform:uppercase;letter-spacing:.8px;
  color:var(--t2);margin-bottom:7px;
}
.field input{
  width:100%;padding:12px 14px;border-radius:11px;
  border:1px solid rgba(255,255,255,.08);
  background:rgba(255,255,255,.04);
  color:var(--t);font-size:14px;font-family:inherit;
  outline:none;transition:all .18s;
}
.field input:focus{
  border-color:rgba(245,200,66,.4);
  background:rgba(245,200,66,.04);
  box-shadow:0 0 0 3px rgba(245,200,66,.08);
}
.field input::placeholder{color:var(--t3)}
.err-box{
  background:rgba(244,63,94,.08);border:1px solid rgba(244,63,94,.22);
  border-radius:9px;padding:10px 13px;font-size:12px;color:#f43f5e;
  margin-bottom:16px;display:none;animation:shk .3s ease;
}
@keyframes shk{0%,100%{transform:none}25%{transform:translateX(-4px)}75%{transform:translateX(4px)}}
.btn-login{
  width:100%;padding:14px;border-radius:12px;
  background:linear-gradient(135deg,#f5c842,#d97706);
  color:#000;border:none;font-size:14px;font-weight:800;
  font-family:'Outfit',sans-serif;cursor:pointer;
  transition:all .2s;letter-spacing:.3px;
  box-shadow:0 6px 24px rgba(245,200,66,.35),inset 0 1px 0 rgba(255,255,255,.25);
  display:flex;align-items:center;justify-content:center;gap:8px;
}
.btn-login:hover:not(:disabled){transform:translateY(-2px);box-shadow:0 12px 32px rgba(245,200,66,.45)}
.btn-login:active:not(:disabled){transform:translateY(0)}
.btn-login:disabled{opacity:.5;cursor:not-allowed;transform:none}
.login-footer{text-align:center;margin-top:20px;font-size:11px;color:var(--t3)}
.sp{width:18px;height:18px;border-radius:50%;border:2px solid rgba(0,0,0,.2);border-top-color:#000;animation:spin .65s linear infinite;display:none}
@keyframes spin{to{transform:rotate(360deg)}}
</style>
</head>
<body>
<div class="login-wrap">
  <div class="login-brand">
    <div class="login-icon">🕌</div>
    <div class="login-title">GIC Teacher Portal</div>
    <div class="login-sub">GLOBAL ISLAMIC CARE &mdash; Teacher Login</div>
  </div>
  <div class="login-card" style="position:relative">
    <div class="err-box" id="err"></div>
    <div class="field">
      <label>Username</label>
      <input id="u" type="text" placeholder="Enter your username" autocomplete="username">
    </div>
    <div class="field">
      <label>Password</label>
      <input id="p" type="password" placeholder="Enter your password" autocomplete="current-password">
    </div>
    <button class="btn-login" id="btn" onclick="doLogin()">
      <div class="sp" id="sp"></div>
      <span id="btn-lbl">🔐 Login</span>
    </button>
  </div>
  <div class="login-footer">Global Islamic Care &mdash; Teacher Portal</div>
</div>
<script>
document.getElementById('p').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') doLogin();
});
document.getElementById('u').addEventListener('keydown', function(e) {
  if (e.key === 'Enter') document.getElementById('p').focus();
});
function doLogin() {
  var u = document.getElementById('u').value.trim();
  var p = document.getElementById('p').value;
  var err = document.getElementById('err');
  var btn = document.getElementById('btn');
  var sp = document.getElementById('sp');
  var lbl = document.getElementById('btn-lbl');
  err.style.display = 'none';
  if (!u || !p) { err.textContent = 'Please enter Username and Password.'; err.style.display = 'block'; return; }
  btn.disabled = true; sp.style.display = 'block'; lbl.textContent = 'Logging in...';
  fetch('/api/teacher/login', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({username: u, password: p})
  }).then(function(r) { return r.json(); }).then(function(d) {
    if (d.success) {
      localStorage.setItem('gic_teacher_token', d.token);
      localStorage.setItem('gic_teacher_name', d.teacher.name);
      localStorage.setItem('gic_teacher_id', d.teacher.id);
      window.location.href = '/teacher';
    } else {
      err.textContent = d.error || 'Login failed.';
      err.style.display = 'block';
      btn.disabled = false; sp.style.display = 'none'; lbl.textContent = '🔐 Login';
    }
  }).catch(function() {
    err.textContent = 'Network error. Please try again.';
    err.style.display = 'block';
    btn.disabled = false; sp.style.display = 'none'; lbl.textContent = '🔐 Login';
  });
}
// ✅ Already logged in → redirect
var tok = localStorage.getItem('gic_teacher_token');
if (tok) {
  fetch('/api/teacher/me', {headers:{'x-teacher-token':tok}})
    .then(function(r){ if(r.ok) window.location.href = '/teacher'; })
    .catch(function(){});
}
</script>
</body>
</html>`;

// ════════════════════════════════════════════════════════════════
//  TEACHER DASHBOARD PAGE
// ════════════════════════════════════════════════════════════════
const TEACHER_DASHBOARD = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<script>function hcov(id){var el=document.getElementById(id);if(el)el.classList.add("h");}window.hcov=hcov;</script>
<title>GIC — Teacher Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Outfit:wght@600;700;800;900&family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#04080f;--bg2:#090f1c;--bg3:#0e1828;--bg4:#141f32;
  --b:rgba(255,255,255,.06);--b2:rgba(255,255,255,.11);
  --gold:#f5c842;--gold2:#d97706;
  --green:#10b981;--red:#f43f5e;--amber:#f59e0b;--blue:#3b82f6;--purple:#8b5cf6;
  --t:#e8edf5;--t2:#8fa3bf;--t3:#4a5a72;
  --tab-h:56px;--radius-md:12px;--radius-lg:16px;
  --trans:.18s cubic-bezier(.4,0,.2,1);
}
html,body{height:100%;overflow:hidden;font-family:'Inter','Hind Siliguri',sans-serif;background:var(--bg);color:var(--t)}
body{display:flex;flex-direction:column;position:relative}
body::before{
  content:'';position:fixed;inset:0;pointer-events:none;
  background:
    radial-gradient(ellipse 60% 45% at 10% 8%,rgba(245,200,66,.04),transparent),
    radial-gradient(ellipse 50% 40% at 90% 85%,rgba(16,185,129,.03),transparent);
}

/* ── Nav ── */
.nav{
  height:var(--tab-h);flex-shrink:0;position:relative;z-index:100;
  background:rgba(4,8,15,.95);backdrop-filter:blur(20px);
  border-bottom:1px solid rgba(245,200,66,.08);
  display:flex;align-items:center;padding:0 10px;gap:3px;overflow-x:auto;
  box-shadow:0 1px 0 rgba(255,255,255,.04),0 4px 24px rgba(0,0,0,.5);
}
.nav::-webkit-scrollbar{height:0}
.brand{display:flex;align-items:center;gap:9px;padding-right:12px;margin-right:4px;border-right:1px solid var(--b);flex-shrink:0}
.brand-icon{width:30px;height:30px;border-radius:8px;background:linear-gradient(135deg,#f5c842,#d97706);display:flex;align-items:center;justify-content:center;font-size:15px;box-shadow:0 0 14px rgba(245,200,66,.35);flex-shrink:0}
.brand-name{font-size:11.5px;font-weight:800;font-family:'Outfit',sans-serif}
.brand-role{font-size:9px;color:var(--t3);margin-top:1px;letter-spacing:.5px}
.tab{
  display:flex;align-items:center;gap:5px;padding:6px 12px;border-radius:9px;
  border:1px solid transparent;cursor:pointer;font-size:11px;font-weight:600;color:var(--t3);
  white-space:nowrap;transition:all var(--trans);flex-shrink:0;background:transparent;font-family:inherit;
}
.tab-ico{font-size:12px;transition:transform .2s}
.tab:hover{background:rgba(255,255,255,.05);color:var(--t2)}
.tab:hover .tab-ico{transform:scale(1.15)}
.tab.on{background:linear-gradient(135deg,rgba(245,200,66,.13),rgba(245,200,66,.05));border-color:rgba(245,200,66,.22);color:var(--gold)}
.tab.on .tab-ico{transform:scale(1.1)}
.nav-div{width:1px;height:20px;background:var(--b);flex-shrink:0;margin:0 2px}
.nav-right{margin-left:auto;display:flex;align-items:center;gap:8px;flex-shrink:0;padding-left:8px;border-left:1px solid var(--b)}
.teacher-badge{
  display:flex;align-items:center;gap:6px;padding:5px 10px;border-radius:8px;
  background:rgba(245,200,66,.08);border:1px solid rgba(245,200,66,.18);
  font-size:10.5px;font-weight:700;color:var(--gold);
}
.clk{font-size:11px;font-weight:800;color:var(--gold);font-family:'Outfit',sans-serif}
.btn-logout{
  padding:5px 10px;border-radius:7px;border:1px solid rgba(244,63,94,.22);
  background:rgba(244,63,94,.07);color:#f43f5e;font-size:10.5px;font-weight:700;
  cursor:pointer;font-family:inherit;transition:all .15s;
}
.btn-logout:hover{background:rgba(244,63,94,.14)}

/* ── Panels ── */
.cnt{flex:1;position:relative;overflow:hidden;z-index:1}
.pnl{position:absolute;inset:0;opacity:0;pointer-events:none;transition:opacity .22s;z-index:1}
.pnl.on{opacity:1;pointer-events:auto;z-index:2}
.pnl iframe{width:100%;height:100%;border:none;display:block}
.sp-pnl{height:100%;overflow-y:auto}
.sp-pnl::-webkit-scrollbar{width:4px}
.sp-pnl::-webkit-scrollbar-thumb{background:rgba(255,255,255,.07);border-radius:4px}
.hw{max-width:840px;margin:0 auto;padding:20px 16px 60px;width:100%}

/* Loading overlay */
.cov{position:absolute;inset:0;background:var(--bg2);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:var(--t2);font-size:11px;transition:opacity .3s;z-index:5}
.cov.h{opacity:0;pointer-events:none}
.sp{width:24px;height:24px;border-radius:50%;border:2.5px solid rgba(245,200,66,.15);border-top-color:var(--gold);animation:spin .7s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}

/* ── Cards ── */
.hero{
  background:linear-gradient(120deg,rgba(245,200,66,.08),rgba(16,185,129,.04));
  border:1px solid rgba(245,200,66,.12);border-radius:var(--radius-lg);
  padding:20px 24px;margin-bottom:14px;position:relative;overflow:hidden;
}
.hero::after{content:'🕌';position:absolute;right:18px;top:50%;transform:translateY(-50%);font-size:52px;opacity:.06;pointer-events:none}
.hero h1{font-size:18px;font-weight:900;font-family:'Outfit',sans-serif;margin-bottom:4px}
.hero em{color:var(--gold);font-style:normal}
.hero p{font-size:11.5px;color:var(--t2);line-height:1.7}

.card{background:var(--bg2);border:1px solid var(--b);border-radius:var(--radius-md);padding:18px 20px;margin-bottom:14px}
.sec{font-size:9.5px;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--t3);margin:18px 0 10px;display:flex;align-items:center;gap:8px}
.sec::after{content:'';flex:1;height:1px;background:linear-gradient(90deg,var(--b),transparent)}

/* Student cards */
.stu-toolbar{display:flex;align-items:center;gap:10px;margin-bottom:14px}
.stu-search{flex:1;display:flex;align-items:center;gap:8px;background:var(--bg2);border:1px solid var(--b);border-radius:10px;padding:8px 12px;transition:border-color .18s}
.stu-search:focus-within{border-color:rgba(245,200,66,.3)}
.stu-search input{flex:1;background:transparent;border:none;outline:none;color:var(--t);font-size:12.5px;font-family:inherit}
.stu-search input::placeholder{color:var(--t3)}
.stu-count{display:inline-flex;align-items:center;justify-content:center;min-width:22px;height:22px;padding:0 7px;border-radius:11px;background:rgba(245,200,66,.12);color:var(--gold);font-size:11px;font-weight:700}
.stu-card{background:var(--bg2);border:1px solid var(--b);border-radius:var(--radius-md);padding:12px 14px;display:flex;align-items:center;gap:12px;transition:all .16s;position:relative;overflow:hidden}
.stu-card::before{content:'';position:absolute;left:0;top:0;bottom:0;width:0;background:linear-gradient(180deg,var(--gold),var(--gold2));transition:width .2s;border-radius:var(--radius-md) 0 0 var(--radius-md)}
.stu-card:hover::before{width:3px}
.stu-card:hover{border-color:rgba(255,255,255,.1);transform:translateX(2px)}
.stu-avatar{width:38px;height:38px;border-radius:10px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;font-family:'Outfit',sans-serif;letter-spacing:-.5px}
.av-hifz{background:rgba(245,197,24,.15);color:var(--gold)}
.av-nazera{background:rgba(16,185,129,.15);color:var(--green)}
.av-tajweed{background:rgba(59,130,246,.15);color:var(--blue)}
.av-other{background:rgba(139,92,246,.15);color:var(--purple)}
.stu-name{font-size:13px;font-weight:700;color:var(--t);margin-bottom:4px}
.stu-tags{display:flex;flex-wrap:wrap;gap:4px}
.stu-tag{display:inline-flex;align-items:center;gap:3px;background:rgba(255,255,255,.04);border:1px solid var(--b);border-radius:5px;padding:2px 7px;font-size:10px;color:var(--t2)}
.cat-chip{font-weight:700;font-size:9.5px;letter-spacing:.8px;text-transform:uppercase;padding:2px 7px;border-radius:5px}
.chip-hifz{background:rgba(245,197,24,.12);color:var(--gold);border:1px solid rgba(245,197,24,.2)}
.chip-nazera{background:rgba(16,185,129,.1);color:var(--green);border:1px solid rgba(16,185,129,.2)}
.chip-tajweed{background:rgba(59,130,246,.1);color:var(--blue);border:1px solid rgba(59,130,246,.2)}
.chip-other{background:rgba(139,92,246,.1);color:var(--purple);border:1px solid rgba(139,92,246,.2)}

/* Toast */
#ts{position:fixed;bottom:14px;right:14px;z-index:999;display:flex;flex-direction:column;gap:5px}
.tt{background:rgba(9,15,28,.95);backdrop-filter:blur(12px);border:1px solid var(--b2);border-radius:9px;padding:9px 14px;font-size:11px;box-shadow:0 6px 24px rgba(0,0,0,.6);animation:tin .28s cubic-bezier(.34,1.56,.64,1) forwards}
@keyframes tin{from{opacity:0;transform:translateX(12px)}to{opacity:1;transform:none}}

/* Stats */
.stats-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:14px}
.stat-card{background:var(--bg2);border:1px solid var(--b);border-radius:var(--radius-md);padding:14px 16px;text-align:center}
.stat-val{font-size:24px;font-weight:900;font-family:'Outfit',sans-serif;color:var(--gold);line-height:1}
.stat-lbl{font-size:10px;color:var(--t3);margin-top:5px;text-transform:uppercase;letter-spacing:.8px;font-weight:700}
</style>
</head>
<body>

<!-- ── Nav ── -->
<nav class="nav">
  <div class="brand">
    <div class="brand-icon">🕌</div>
    <div><div class="brand-name">GIC Teacher</div><div class="brand-role">TEACHER PORTAL</div></div>
  </div>
  <button class="tab on" data-t="home" onclick="go('home')"><span class="tab-ico">🏠</span> Home</button>
  <button class="tab" data-t="students" onclick="go('students')"><span class="tab-ico">👥</span> My Students</button>
  <div class="nav-div"></div>
  <button class="tab" data-t="daily" onclick="go('daily')"><span class="tab-ico">&#128196;</span> Daily Report</button>
  <div class="nav-right">
    <div class="teacher-badge">👨‍🏫 <span id="t-name">...</span></div>
    <div class="clk" id="clk">--:--</div>
    <button class="btn-logout" onclick="doLogout()">🚪 Logout</button>
  </div>
</nav>

<div class="cnt">

  <!-- HOME -->
  <div class="pnl on" id="pp-home">
    <div class="sp-pnl">
      <div class="hw">
        <div class="hero">
          <h1>Assalamu Alaikum, <em id="hero-name">Teacher</em> 👋</h1>
          <p>Welcome to your Teacher Dashboard. Generate Daily Reports and Invoices for your assigned students here.</p>
        </div>
        <div class="stats-grid">
          <div class="stat-card">
            <div class="stat-val" id="stat-stu">—</div>
            <div class="stat-lbl">My Students</div>
          </div>
        </div>
        <div class="sec">🛠️ Quick Access</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:14px">
          <button onclick="go('students')" style="display:flex;align-items:center;gap:10px;padding:13px 14px;border-radius:11px;background:rgba(255,255,255,.04);border:1px solid var(--b);cursor:pointer;text-align:left;font-family:inherit;color:var(--t);transition:all .18s" onmouseover="this.style.background='rgba(255,255,255,.07)'" onmouseout="this.style.background='rgba(255,255,255,.04)'">
            <span style="font-size:20px;width:32px;text-align:center">👥</span>
            <div><div style="font-size:12px;font-weight:700;margin-bottom:2px">My Students</div><div style="font-size:10px;color:var(--t3)">View list</div></div>
          </button>
          <button onclick="go('daily')" style="display:flex;align-items:center;gap:10px;padding:13px 14px;border-radius:11px;background:rgba(255,255,255,.04);border:1px solid var(--b);cursor:pointer;text-align:left;font-family:inherit;color:var(--t);transition:all .18s" onmouseover="this.style.background='rgba(255,255,255,.07)'" onmouseout="this.style.background='rgba(255,255,255,.04)'">
            <span style="font-size:20px;width:32px;text-align:center">&#128196;</span>
            <div><div style="font-size:12px;font-weight:700;margin-bottom:2px">Daily Report</div><div style="font-size:10px;color:var(--t3)">Create report</div></div>
          </button>
        </div>
        <div class="card" style="background:rgba(245,200,66,.04);border-color:rgba(245,200,66,.15)">
          <div style="font-size:11.5px;color:var(--amber);line-height:1.7;display:flex;gap:9px">
            <span>💡</span>
            <div><strong>Teacher Dashboard:</strong> Only your assigned students are shown here. Contact Admin to add new students or manage the WhatsApp Bot.</div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <!-- MY STUDENTS -->
  <div class="pnl" id="pp-students">
    <div class="sp-pnl">
      <div class="hw">
        <div class="hero" style="background:linear-gradient(120deg,rgba(16,185,129,.08),rgba(59,130,246,.04));border-color:rgba(16,185,129,.14)">
          <h1>👥 My Students — <em style="color:var(--green)">List</em></h1>
          <p>List of students assigned to you by Admin.</p>
        </div>
        <div class="stu-toolbar">
          <div class="stu-search">
            <span style="font-size:13px;opacity:.6">🔍</span>
            <input type="text" id="s-search" placeholder="Search by name or phone..." oninput="filterMyStudents(this.value)">
          </div>
          <div style="display:flex;align-items:center;gap:6px;white-space:nowrap;font-size:11px;color:var(--t2)">
            Total <span class="stu-count" id="s-cnt">0</span>
          </div>
        </div>
        <div id="s-list" style="display:flex;flex-direction:column;gap:7px">
          <div style="color:var(--t3);font-size:12px;padding:24px;text-align:center">Loading...</div>
        </div>
      </div>
    </div>
  </div>

  <!-- DAILY REPORT -->
  <div class="pnl" id="pp-daily">
    <div class="cov" id="cv-daily"><div class="sp"></div><span>Loading Daily Report...</span></div>
    <iframe id="fr-daily" src="" onload="hcov('cv-daily')"></iframe>
  </div>

</div>

<div id="ts"></div>
<script>
// ── Auth check ──────────────────────────────────────────────
var _tok = localStorage.getItem('gic_teacher_token');
var _tname = localStorage.getItem('gic_teacher_name') || 'Teacher';
if (!_tok) { window.location.href = '/teacher/login'; }

// Set teacher name
var tnEl = document.getElementById('t-name');
var hEl  = document.getElementById('hero-name');
if (tnEl) tnEl.textContent = _tname;
if (hEl)  hEl.textContent  = _tname;

// ── State ────────────────────────────────────────────────────
var _ld = {daily: false, invoice: false};
var _myStudents = [];

// ── Toast ────────────────────────────────────────────────────
function toast(msg) {
  var ts = document.getElementById('ts');
  var d = document.createElement('div');
  d.className = 'tt'; d.textContent = msg;
  ts.appendChild(d);
  setTimeout(function() { if (d.parentNode) d.parentNode.removeChild(d); }, 3500);
}

// ── Navigation ───────────────────────────────────────────────
function go(t) {
  var tabs   = document.querySelectorAll('.tab');
  var panels = document.querySelectorAll('.pnl');
  for (var i=0; i<tabs.length; i++) tabs[i].classList.remove('on');
  for (var i=0; i<panels.length; i++) panels[i].classList.remove('on');
  var ab = document.querySelector('[data-t="' + t + '"]');
  var ap = document.getElementById('pp-' + t);
  if (ab) ab.classList.add('on');
  if (ap) ap.classList.add('on');
  if (t === 'daily' && !_ld.daily) {
    _ld.daily = true;
    var fr = document.getElementById('fr-daily');
    if (fr) fr.src = '/tools/report/daily-report-generator.html';
  }
  if (t === 'invoice' && !_ld.invoice) {
    _ld.invoice = true;
    var fr = document.getElementById('fr-invoice');
    if (fr) fr.src = '/tools/invoice/invoice-generator.html';
  }
  if (t === 'students') loadMyStudents();
  if (t === 'home') loadStats();
}

function hcov(id) {
  var el = document.getElementById(id);
  if (el) el.classList.add('h');
}

// ── Load teacher's students ───────────────────────────────────
function loadMyStudents() {
  fetch('/api/teacher/students', {headers:{'x-teacher-token':_tok}})
    .then(function(r){
      if (r.status === 401) { localStorage.clear(); window.location.href = '/teacher/login'; }
      return r.json();
    })
    .then(function(data) {
      _myStudents = data;
      renderMyStudents(_myStudents);
      var cnt = document.getElementById('s-cnt');
      if (cnt) cnt.textContent = data.length;
    }).catch(function() {
      var el = document.getElementById('s-list');
      if (el) el.innerHTML = '<div style="color:var(--red);font-size:12px;padding:20px;text-align:center">&#10060; Failed to load</div>';
    });
}

function filterMyStudents(q) {
  var list = q.trim()
    ? _myStudents.filter(function(s){ return (s.name||'').toLowerCase().indexOf(q.toLowerCase())>=0 || (s.phone||'').indexOf(q)>=0; })
    : _myStudents;
  renderMyStudents(list);
}

function renderMyStudents(list) {
  var el = document.getElementById('s-list');
  if (!el) return;
  if (!list.length) {
    el.innerHTML = '<div style="color:var(--t3);padding:40px;text-align:center;font-size:12px"><div style="font-size:38px;opacity:.3;margin-bottom:10px">👥</div><div>No students assigned to you.<br>Please contact Admin.</div></div>';
    return;
  }
  var avC = {hifz:'av-hifz',nazera:'av-nazera',tajweed:'av-tajweed',other:'av-other'};
  var chipC = {hifz:'chip-hifz',nazera:'chip-nazera',tajweed:'chip-tajweed',other:'chip-other'};
  var html = '';
  for (var i=0; i<list.length; i++) {
    var s = list[i];
    var cat = s.category || 'other';
    var init = (s.name||'?').split(' ').map(function(w){return w[0]||'';}).slice(0,2).join('').toUpperCase();
    var tags = '';
    if (s.phone) tags += '<span class="stu-tag">📱 ' + s.phone + '</span>';
    if (s.phone2) tags += '<span class="stu-tag">📱₂ ' + s.phone2 + '</span>';
    if (s.class) tags += '<span class="stu-tag">📚 ' + s.class + '</span>';
    if (s.schedule) tags += '<span class="stu-tag">⏰ ' + s.schedule + '</span>';
    if (s.fee) tags += '<span class="stu-tag">Tk ' + s.fee + '/mo</span>';
    if (s.category) tags += '<span class="cat-chip ' + (chipC[cat]||chipC.other) + '">' + cat.toUpperCase() + '</span>';
    html += '<div class="stu-card"><div class="stu-avatar ' + (avC[cat]||avC.other) + '">' + init + '</div>' +
      '<div style="flex:1;min-width:0"><div class="stu-name">' + (s.name||'—') + '</div><div class="stu-tags">' + tags + '</div></div></div>';
  }
  el.innerHTML = html;
}

function loadStats() {
  fetch('/api/teacher/students', {headers:{'x-teacher-token':_tok}})
    .then(function(r){ return r.json(); })
    .then(function(d){ var el=document.getElementById('stat-stu'); if(el) el.textContent=d.length; })
    .catch(function(){});
}

// ── Logout ───────────────────────────────────────────────────
function doLogout() {
  if (!confirm('Do you want to logout?')) return;
  fetch('/api/teacher/logout', {method:'POST', headers:{'x-teacher-token':_tok}}).catch(function(){});
  localStorage.removeItem('gic_teacher_token');
  localStorage.removeItem('gic_teacher_name');
  localStorage.removeItem('gic_teacher_id');
  window.location.href = '/teacher/login';
}

// ── Clock ────────────────────────────────────────────────────
setInterval(function() {
  var el = document.getElementById('clk');
  if (el) el.textContent = new Date().toLocaleTimeString('en-US',{timeZone:'Asia/Dhaka',hour:'2-digit',minute:'2-digit',hour12:true});
}, 1000);

// ── Init ─────────────────────────────────────────────────────
loadStats();
// Verify token on load
fetch('/api/teacher/me', {headers:{'x-teacher-token':_tok}})
  .then(function(r){ if(r.status===401){ localStorage.clear(); window.location.href='/teacher/login'; } })
  .catch(function(){});
</script>
</body>
</html>`;


const REPORT_DASH = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>GIC Report Bot</title><link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet"><style>:root{--p:#0B2447;--a:#F9A826;--s:#10B981;--d:#EF4444;--w:#F59E0B;--bg:#F1F5F9;--sf:#fff;--br:#E2E8F0}*{margin:0;padding:0;box-sizing:border-box}body{font-family:'Inter',sans-serif;background:var(--bg);color:#1F2937;height:100vh;overflow-y:auto}.hdr{background:linear-gradient(135deg,var(--p),#1e3a5f);color:#fff;padding:16px 28px;display:flex;align-items:center;gap:12px;box-shadow:0 4px 20px rgba(0,0,0,.2)}.hdr h1{font-size:18px;font-weight:800}.hdr p{font-size:11px;color:rgba(255,255,255,.7)}.badge{background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);padding:5px 12px;border-radius:20px;font-size:12px;font-weight:700;margin-left:auto}.ct{max-width:860px;margin:20px auto;padding:0 16px 40px;display:flex;flex-direction:column;gap:14px}.card{background:var(--sf);border-radius:13px;padding:18px;box-shadow:0 2px 10px rgba(0,0,0,.05);border:1px solid var(--br)}.ctitle{font-size:13px;font-weight:700;color:var(--p);margin-bottom:12px}.sr{display:flex;align-items:center;gap:10px}.dot{width:11px;height:11px;border-radius:50%;flex-shrink:0}.dot.g{background:var(--s);box-shadow:0 0 5px var(--s)}.dot.y{background:var(--w)}.dot.r{background:var(--d)}.dot.x{background:#9CA3AF}.stx{font-weight:700;font-size:13px}.ssx{font-size:11px;color:#6B7280;margin-top:1px}#qr-sec{text-align:center;padding:14px;display:none}#qr-img{max-width:200px;border-radius:10px;border:2px solid var(--a)}.ig{display:grid;grid-template-columns:1fr 1fr;gap:9px}.ii{background:#F8FAFC;border-radius:8px;padding:11px;border:1px solid var(--br)}.il{font-size:10px;text-transform:uppercase;letter-spacing:.5px;color:#6B7280;font-weight:700;margin-bottom:2px}.iv{font-size:14px;font-weight:700;color:var(--p)}.lb{height:200px;overflow-y:auto;background:#F8FAFC;border-radius:8px;padding:9px;font-family:monospace;font-size:11px;border:1px solid var(--br)}.lb::-webkit-scrollbar{width:3px}.lb::-webkit-scrollbar-thumb{background:#CBD5E1;border-radius:3px}.le{padding:2px 0;border-bottom:1px solid #F1F5F9;display:flex;gap:6px}.lt{color:#9CA3AF;flex-shrink:0}.li{color:#1F2937}.ls{color:var(--s)}.lr{color:var(--d)}.lw{color:var(--w)}.tbl{width:100%;border-collapse:collapse;font-size:12px}.tbl th{background:#F1F5F9;padding:7px 9px;text-align:left;color:#374151;font-weight:700;font-size:10px;text-transform:uppercase}.tbl td{padding:7px 9px;border-top:1px solid var(--br)}.tag{display:inline-block;padding:2px 7px;border-radius:7px;font-size:10px;font-weight:700}.ts{background:#D1FAE5;color:#065F46}.tf{background:#FEE2E2;color:#991B1B}</style></head><body><div class="hdr"><div><h1>📋 GIC Report Bot</h1><p>WhatsApp Report Sender</p></div><div class="badge" id="hst">⏳ Checking...</div></div><div class="ct"><div class="card"><div class="ctitle">📡 WhatsApp Status</div><div class="sr"><div class="dot x" id="dt"></div><div><div class="stx" id="stx">Checking...</div><div class="ssx" id="ssx"></div></div></div><div id="qr-sec"><p style="font-weight:700;color:var(--p);margin-bottom:10px">📱 Scan QR Code</p><img id="qr-img" src="" alt="QR"><p style="font-size:11px;color:#6B7280;margin-top:8px">WhatsApp → Linked Devices → Link a Device</p></div></div><div class="card"><div class="ctitle">📊 Statistics</div><div class="ig"><div class="ii"><div class="il">Sent Today</div><div class="iv" id="s-td">—</div></div><div class="ii"><div class="il">Total Sent</div><div class="iv" id="s-tt">—</div></div><div class="ii"><div class="il">Current Time</div><div class="iv" id="s-tm">—</div></div><div class="ii"><div class="il">Port</div><div class="iv">3000</div></div></div></div><div class="card"><div class="ctitle">📨 Sent Reports</div><div style="overflow-x:auto"><table class="tbl"><thead><tr><th>Student</th><th>Number</th><th>Date</th><th>File</th><th>Status</th></tr></thead><tbody id="tb"><tr><td colspan="5" style="text-align:center;color:#9CA3AF;padding:14px">No reports sent yet</td></tr></tbody></table></div></div><div class="card"><div class="ctitle">📋 Live Log</div><div class="lb" id="lb"><div style="color:#9CA3AF">Loading...</div></div></div></div><script>let lT=null;async function fst(){try{const d=await(await fetch('/api/status')).json();const dot=document.getElementById('dt'),st=document.getElementById('stx'),ss=document.getElementById('ssx'),hs=document.getElementById('hst'),qr=document.getElementById('qr-sec');if(d.ready){dot.className='dot g';st.textContent='Connected &amp; Ready';ss.textContent='Reports can be sent';hs.textContent='Connected';qr.style.display='none';}else if(d.status==='qr'){dot.className='dot y';st.textContent='Scan QR Code';hs.textContent='Awaiting QR';qr.style.display='block';document.getElementById('qr-img').src='/api/qr-image?t='+Date.now();}else{dot.className='dot r';st.textContent='Connecting...';ss.textContent='Status: '+d.status;hs.textContent='Waiting';qr.style.display='none';}document.getElementById('s-tm').textContent=new Date().toLocaleTimeString('en-US',{timeZone:'Asia/Dhaka'});}catch(e){}}async function fsl(){try{const data=await(await fetch('/api/sent-log')).json();const tb=document.getElementById('tb');document.getElementById('s-tt').textContent=data.length;const today=new Date().toLocaleDateString('en-CA',{timeZone:'Asia/Dhaka'});document.getElementById('s-td').textContent=data.filter(d=>d.dateRaw===today).length;if(!data.length){tb.innerHTML='<tr><td colspan="5" style="text-align:center;color:#9CA3AF;padding:14px">No reports sent yet</td></tr>';return;}tb.innerHTML=data.slice(0,30).map(d=>\`<tr><td style="font-weight:700">\${d.studentName||'—'}</td><td style="color:#6B7280">\${d.phone?'+'+d.phone:'—'}</td><td style="font-size:11px;color:#6B7280">\${d.sentAt||'—'}</td><td style="font-size:10px">\${d.filename||'—'}</td><td><span class="tag \${d.success?'ts':'tf'}">\${d.success?'Sent':'Failed'}</span></td></tr>\`).join('');}catch(e){}}async function flg(){try{const url=lT?'/api/logs?since='+lT:'/api/logs';const data=await(await fetch(url)).json();if(!data.length)return;lT=data[data.length-1].time;const b=document.getElementById('lb');const atB=b.scrollHeight-b.clientHeight<=b.scrollTop+8;const tc={info:'li',success:'ls',error:'lr',warn:'lw'};data.forEach(l=>{const el=document.createElement('div');el.className='le';el.innerHTML=\`<span class="lt">\${l.time.slice(11,19)}</span><span class="\${tc[l.type]||'li'}">\${l.msg}</span>\`;b.appendChild(el);});if(atB)b.scrollTop=b.scrollHeight;const ph=b.querySelector('[style*="color:#9CA3AF"]');if(ph)ph.remove();}catch(e){}}fst();fsl();flg();setInterval(fst,4000);setInterval(fsl,8000);setInterval(flg,3000);</script></body></html>`;

