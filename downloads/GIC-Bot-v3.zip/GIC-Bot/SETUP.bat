﻿@echo off
title GIC Bot — প্রথমবার সেটআপ
chcp 65001 >nul
color 0A

echo.
echo  ══════════════════════════════════════
echo     GIC Bot — Global Islamic Care
echo     প্রথমবার সেটআপ শুরু হচ্ছে...
echo  ══════════════════════════════════════
echo.

REM Step 1: Check Node.js
echo [1/3] Node.js চেক করা হচ্ছে...
node -v >nul 2>&1
if errorlevel 1 (
    echo.
    echo  ❌ Node.js পাওয়া যায়নি!
    echo  👉 https://nodejs.org থেকে Node.js ইন্সটল করুন
    echo  তারপর এই ফাইলটি আবার চালান।
    echo.
    pause
    start https://nodejs.org
    exit /b 1
)
echo  ✅ Node.js পাওয়া গেছে!

REM Step 2: Create local folder
echo [2/3] GIC Local ফোল্ডার তৈরি হচ্ছে...
if not exist "C:\GIC_Local" mkdir "C:\GIC_Local"

REM Step 3: Install packages
echo [3/3] WhatsApp প্যাকেজ ইন্সটল হচ্ছে (একটু সময় লাগবে)...
cd /d "%~dp0GIC App"
copy /Y GIC.js "C:\GIC_Local\GIC.js" >nul
cd /d "C:\GIC_Local"
npm install whatsapp-web.js express puppeteer qrcode qrcode-terminal

echo.
echo  ══════════════════════════════════════
echo   ✅ সেটআপ সম্পন্ন হয়েছে!
echo   এখন GIC_Start.bat চালান।
echo  ══════════════════════════════════════
echo.
pause