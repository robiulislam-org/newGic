@echo off
title GIC Bot - Global Islamic Care
chcp 65001 > nul

REM Purono process bondho
taskkill /f /im node.exe >nul 2>&1

set "LOCAL=C:\GIC_Local"
set "GIC_DATA_ROOT=%~dp0"
if "%GIC_DATA_ROOT:~-1%"=="\" set "GIC_DATA_ROOT=%GIC_DATA_ROOT:~0,-1%"

if not exist "%GIC_DATA_ROOT%\GIC App\GIC.js" (
    set "GIC_DATA_ROOT=g:\My Drive\My Laptop Backup\D_Drive_Files\GIC Student control"
)

if not exist "%LOCAL%" mkdir "%LOCAL%"

REM GIC.js update
copy /Y "%GIC_DATA_ROOT%\GIC App\GIC.js" "%LOCAL%\GIC.js" > nul

REM Bot chalu
cd /d "%LOCAL%"
node GIC.js

pause