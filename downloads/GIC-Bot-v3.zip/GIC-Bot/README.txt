﻿╔══════════════════════════════════════════════════════════╗
║           GIC Bot — Global Islamic Care                  ║
║           Version 3.0.0                                  ║
╚══════════════════════════════════════════════════════════╝

ইন্সটলেশন গাইড:
━━━━━━━━━━━━━━━━

ধাপ ১: Node.js ইন্সটল করুন
  → https://nodejs.org থেকে LTS version ডাউনলোড করুন
  → ইন্সটল করুন (সব ডিফল্ট সেটিং রাখুন)
  → CMD খুলে "node -v" টাইপ করে চেক করুন

ধাপ ২: এই ফোল্ডারটি C:\GIC_Bot\ তে রাখুন
  → ZIP Extract করুন → C:\GIC_Bot\ ফোল্ডারে কপি করুন

ধাপ ৩: প্রথমবার সেটআপ
  → "GIC App" ফোল্ডারে যান
  → CMD খুলুন এবং টাইপ করুন: npm install
  → সব package install হবে (একটু সময় লাগবে)

ধাপ ৪: বট চালু করুন
  → GIC_Start.bat ফাইলে ডাবল-ক্লিক করুন
  → ব্রাউজারে যান: http://localhost:3000

ধাপ ৫: WhatsApp সংযোগ
  → ড্যাশবোর্ডে QR কোড দেখাবে
  → WhatsApp → Linked Devices → QR Scan করুন

সাহায্যের জন্য:
  WhatsApp: 01814-812233
  ওয়েবসাইট: https://globalislamiccare.com/teacher-tools

© 2025 Global Islamic Care — সকল অধিকার সংরক্ষিত